# FULL SCIENTIFIC PAPER AUDIT — bản v0.1.0

Ngày kiểm định: **10/11/2026**, múi giờ Asia/Bangkok. Tác giả bản thảo: **Viet Nam Tran**, Faculty of Environment, Van Lang University, Ho Chi Minh City, Vietnam.

**Kết luận biên tập: CHƯA NÊN NỘP. Cần major revision về độ vững của thiết kế, diễn giải và khả năng truy cập/tái lập.** Đây là một nghiên cứu tính toán thực, có nguồn dữ liệu và nhiều kết quả số kiểm tra được. Chưa có cơ sở để kết luận gian lận hoặc bịa kết quả. Tuy nhiên, chạy lại ra cùng con số chưa chứng minh lựa chọn mô hình, suy luận thống kê hay đóng góp đã đủ thuyết phục.

Đối tượng chính: *Information availability and conditional reliability in 12-hour wastewater inflow-volume forecasting: a reproducible single-plant audit*, PDF 14 trang và Markdown trong `D:/P2/publication`. Commit được nhận diện trong hồ sơ: `da3b755d0b06aaa72829fd069a8e3c1133eb1796`, release `v0.1.0`. SHA-256 của PDF: `6f93d3b35b4979807b176ba5c570fd971dc59f98d81dc9f0a3786a46e7f9241b`.

Đây là kiểm định đối kháng theo **năm vai trò chuyên môn**, không phải năm phản biện viên con người độc lập. Cùng hệ thống trợ lý đã tham gia tạo bản thảo trước đó; do đó không thể tự chứng nhận tính độc lập tổ chức hoặc thay thế external peer review. Để giảm tự xác nhận, lần này đã dựng lại một số đại lượng từ dữ liệu gốc, chạy các phản chứng, đối chiếu nguồn bên ngoài và lưu cả kết quả bất lợi. Không sửa bản thảo, dữ liệu gốc hoặc quyền truy cập GitHub trong đợt audit.

## 1. Phạm vi và giới hạn kiểm định

Đã đọc toàn bộ bản thảo Markdown; trích xuất văn bản của cả 14 trang PDF; xem bản dựng của tất cả trang, hai bảng và năm hình; đọc mã phân tích, tải dữ liệu, kiểm tra kết quả, tính lại bootstrap, tạo bảng/tài liệu tham khảo và dựng PDF. Đã kiểm tra proposal, protocol, báo cáo lựa chọn đề tài, báo cáo kết quả, README, giấy phép, hồ sơ phiên bản, nhật ký và danh mục 87 mục trong ZIP.

Các kiểm tra tính toán mới đã thực hiện:

- Dựng lại căn chỉnh UTC và kênh flow sau screening từ `wwtp.csv`; đối chiếu checksum hai archive với metadata Zenodo đã lưu.
- Cộng lại target theo timestamp cho cả ba horizon; kiểm tra eligibility, ngưỡng high-volume và toàn bộ chín ranh giới inner CV.
- Tính lại **420 giá trị point metric** và **336 giá trị pooled-interval metric** từ các dự báo đã lưu. Đây là số đại lượng, không phải số mẫu độc lập.
- Huấn luyện lại ba cấu hình HGB chính ở horizon 12 giờ với tham số đã chọn; kiểm tra dự báo và 24 giá trị coverage pooled/wet–dry từ calibration tái tính.
- Chạy ba phép thử hậu kiểm: HGB dùng absolute-error loss, bỏ annual features, bỏ toàn bộ calendar features. Không tuning theo test; nhưng đây vẫn là **post hoc stress tests**, không phải xác nhận trên test mới.
- Tính lại các đợt high-volume, leave-one-episode-out, toàn bộ 12 pha cửa sổ không chồng lấn tại horizon 12 giờ; chạy so sánh bootstrap và kiểm tra rank quantile.
- Tái tạo lỗi chương trình báo PASS khi không so sánh tệp nào, trong thư mục kiểm thử riêng.
- Kiểm tra metadata GitHub bằng kết nối được xác thực và thử tải công khai không đăng nhập. Rà soát lại nguồn học thuật và metadata DOI.

**Không thực hiện trong đợt audit:** chạy lại toàn bộ grid search ở cả ba horizon trong một môi trường mới thứ hai; đo sensor tại nhà máy; xác nhận lịch sử thay đổi protocol từ một registry độc lập; kiểm định ngoại nhà máy; triển khai forecast thật; kiểm tra tương đồng bằng iThenticate; thẩm định bởi người hoặc xác minh chấp thuận tác giả/cơ quan. Hồ sơ lần tái hiện trước được kiểm tra như chứng cứ lưu trữ, không được mô tả như một phép chạy mới của đợt audit này.

Nhãn bằng chứng dùng xuyên suốt:

| Nhãn | Ý nghĩa |
|---|---|
| **ĐÃ XÁC MINH** | Có đối chiếu nguồn, mã hoặc phép tính cụ thể trong hồ sơ audit. |
| **CÓ DẤU HIỆU VẤN ĐỀ** | Có căn cứ hợp lý nhưng chưa đủ để quy nguyên nhân, ước lượng tác động tổng quát hoặc kết luận sai phạm. |
| **CHƯA THỂ XÁC MINH** | Thiếu dữ liệu, bằng chứng thời điểm, quyền truy cập hoặc xác nhận của tác giả/đơn vị vận hành. |

Mức độ: **Major** = phải xử lý trước nộp; **Moderate** = cần sửa/giải trình có bằng chứng; **Minor** = biên tập hoặc tiện dụng. Không có phát hiện nào hiện đủ căn cứ để gọi là fabrication/falsification hoặc lỗi không thể cứu vãn nghiên cứu.

## 2. Nhận định theo năm vai trò

| Vai trò | Nhận định độc lập về tiêu chí | Quyết định đề nghị |
|---|---|---|
| Senior Researcher | Câu hỏi ranh giới thông tin và độ tin cậy có giá trị, nhưng novelty là trường hợp ứng dụng hẹp; literature bỏ sót công trình gần trực tiếp và chưa có kiểm định đa mùa/địa điểm. | Giữ hướng audit/methodological case study; củng cố so sánh và phạm vi đóng góp. |
| Peer Reviewer | Bài có logic và thừa nhận giới hạn tốt. Tuy nhiên, thứ hạng HGB rất nhạy với loss/calendar; câu chuyện “baseline mạnh hơn mô hình phức tạp” chưa có robustness đủ rộng. | Major revision; không chấp nhận kết luận vượt ngoài những cấu hình đã thử. |
| Statistical & Data Analyst | Target, metric, split và dự báo HGB chính kiểm tra được. Bootstrap có trọng số biên không đều; rank quantile lệch một bậc; chỉ năm đoạn high-volume. | Sửa uncertainty, bổ sung đánh giá theo sự kiện và validation có nhiều mốc. |
| Journal Editor | IMRaD và ngôn ngữ phù hợp bản thảo; thiếu khai báo tác giả/funding/COI và liên kết hình trong thân bài. Chưa xác định tạp chí cuối cùng; chưa chứng minh hợp chuẩn cụ thể của tạp chí. | Chưa nộp; hoàn thiện hồ sơ sau khi xử lý phương pháp. |
| Research Integrity Auditor | Không phát hiện bằng chứng bịa số trong phần đã kiểm tra. Nhưng kho hiện private, script đối chiếu có thể PASS rỗng, và việc protocol có trước fitting chưa có chứng cứ độc lập. | Sửa khả năng kiểm tra công khai và cơ chế fail-closed; không đồng nhất “reproduction” với “replication”. |

## 3. Những kết quả đã được xác minh

### 3.1. Các chỉ số chính của bản thảo là kết quả tính toán có thật

| Đại lượng ở horizon 12 giờ | Giá trị kiểm tra lại | Kết luận |
|---|---:|---|
| Số cửa sổ test | 2.160 | Khớp dữ liệu và eligibility. |
| MAE mean24 | 3.406,6057 m³ | Khớp Table 1. |
| MAE HGB historical | 7.607,1044 m³ | Khớp Table 1 và phép refit. |
| MAE oracle | 2.044,1075 m³ | Khớp Table 1 và phép refit; dùng mưa tương lai. |
| Coverage pooled mean24, toàn test | 87,5% | Khớp dự báo và khoảng đã lưu. |
| Coverage pooled mean24, high-volume | 19/81 = 23,4568% | Khớp Table 2 sau làm tròn. |
| Ngưỡng high-volume | 32.304,9815 m³ | Đúng phân vị 90% của target development. |
| Đoạn high-volume liên tục | 5 | Đúng quy tắc trong mã; chưa xác nhận là năm trận mưa độc lập. |

Ba cấu hình HGB refit có sai khác dự báo tối đa khoảng **7,28 × 10⁻¹² m³** so với CSV đã lưu: tương đương ở độ chính xác số máy, không phải sai lệch khoa học. Các ranh giới inner CV đều có giờ target cuối của train trước validation; khoảng cách tối thiểu một giờ. Không phát hiện train/test label overlap tại các biên đã kiểm tra. Mười hai phép perturbation tương lai không thay đổi historical features tại issue time được kiểm tra. Điều này không chứng minh rằng sensor ở nhà máy thực sự có sẵn đúng timestamp.

Hai archive nguồn khớp MD5 đã lưu; kiểm tra CRC của ZIP không có lỗi; 86 mục có trong manifest nội bộ không có hash mismatch. “Không mismatch” là kiểm tra toàn vẹn gói, không xác nhận tính hợp lý khoa học của mọi câu trong gói.

### 3.2. Phản chứng quan trọng về độ vững của mô hình

| Cấu hình, cùng train/test 12 giờ | MAE test (m³) | Trạng thái |
|---|---:|---|
| Mean24 | 3.406,61 | Kết quả gốc. |
| HGB historical, squared-error loss | 7.607,10 | Kết quả gốc, refit khớp. |
| HGB historical, đổi sang absolute-error loss | **2.723,85** | Hậu kiểm; các tham số khác giữ nguyên. |
| HGB historical, bỏ annual sine/cosine | **3.386,98** | Hậu kiểm; loss và tham số cây giữ nguyên. |
| HGB historical, bỏ mọi calendar feature | 3.681,57 | Hậu kiểm. |

Absolute-error loss cho MAE thấp hơn mean24 khoảng **20,04%** trên chính holdout đã biết. Không được thay kết quả mới vào bài và tuyên bố đây là chiến thắng xác nhận: test đã được xem. Phát hiện chứng minh **độ nhạy của câu chuyện khoa học đối với những lựa chọn hợp lý chưa được khảo sát**, chứ không chứng minh mô hình mới khái quát tốt. Dùng squared-error loss trong nghiên cứu MAE không tự thân là sai; vấn đề là lựa chọn loss không được trình bày đầy đủ và chưa có kiểm tra độ vững trong khi ảnh hưởng rất lớn. Tài liệu chính thức phân biệt các loss của [HistGradientBoostingRegressor](https://scikit-learn.org/1.8/modules/generated/sklearn.ensemble.HistGradientBoostingRegressor.html).

## 4. Sổ phát hiện: vị trí, nguyên nhân, hậu quả và sửa chữa

### A01 — Major — Benchmark nhạy mạnh với loss và calendar

**ĐÃ XÁC MINH.** Vị trí: Methods §2.4, PDF tr. 3–4, Markdown dòng 67–71; Results §3.2, Discussion §4.1, Conclusions; `run_analysis.py` dòng 59, 117–118. Mã bỏ qua tham số `loss`, nên dùng squared error. MAE được dùng để chọn grid nhưng không thử loss phù hợp median; annual predictors có ít chu kỳ năm để học.

**Hậu quả:** chênh lệch MAE 7.607 → 2.724 m³ khi đổi loss và 7.607 → 3.387 m³ khi bỏ annual features cho thấy thất bại của HGB không đại diện chắc chắn cho năng lực của historical information. Câu giới hạn “among evaluated configurations” trong Results là đúng; không nên mở rộng thành kết luận về thuật toán hoặc giá trị thông tin nói chung.

**Khắc phục:** công bố loss; đưa loss/annual ablation vào kế hoạch đánh giá mới, chọn trong development folds; thêm các outer temporal origins hoặc dữ liệu chưa dùng. Báo riêng mọi phân tích phát sinh sau audit. Hoàn thành khi bảng ranking/coverage trên các origin cho thấy phạm vi nào ổn định và phạm vi nào thay đổi, không chọn một cấu hình từ test hiện tại rồi gọi là confirmatory.

### A02 — Major — Một holdout chưa tách được ảnh hưởng mùa, thời gian và tuổi mô hình

**ĐÃ XÁC MINH về thiết kế; CHƯA THỂ XÁC MINH nguyên nhân suy giảm.** Vị trí: §2.4, §3.1, §4.1, §6; `splits.csv`. Development hợp lệ kết thúc 08/08/2024; test bắt đầu 16/11/2024. Mô hình cố định không được refit qua calibration; train mean target 19.942 m³ khác calibration 13.728 và test 16.447 m³.

**Hậu quả:** có thể đánh giá một mô hình bị cũ và lệch mùa, chưa biết kết luận lặp lại ở origin khác. Đây là thiết kế hợp lệ cho fixed-model transfer nhưng chưa đủ đại diện dịch vụ forecasting thường cập nhật. Không có chứng cứ để quy toàn bộ sai số cho distribution shift.

**Khắc phục:** xác định rõ fixed-model estimand; thêm rolling-origin evaluation có train/calibration/test tách biệt, gap đúng horizon và quy tắc refit định trước. Không dùng train+calibration để refit rồi giữ nguyên residual intervals cũ. Nếu thiếu năm mới, giảm tuyên bố tổng quát và trình bày case study.

### A03 — Moderate — Chưa định lượng độ chắc chắn của lợi thế baseline và oracle so với đối chứng mạnh nhất

**ĐÃ XÁC MINH.** Vị trí: Table 1, §3.2, Abstract; vòng bootstrap trong `run_analysis.py` không có mean24–persistence hoặc oracle–mean24. Bài mô tả “lowest MAE” đúng với điểm ước lượng, nhưng chưa cho biết có cơ sở phân biệt hai baseline gần nhau hay không.

**Bằng chứng mới:** mean24–persistence = −333,61 m³; sensitivity circular-block 48 giờ cho khoảng percentile xấp xỉ **[−752,25; +189,56]** m³. Oracle–mean24 = −1.362,50 m³, khác mức −5.563 m³ khi so với HGB yếu. Các khoảng mới chỉ là sensitivity trên test này, không phải CI đã được chứng minh có coverage 95% dưới nonstationarity.

**Khắc phục:** thêm paired comparisons với mean24, phân biệt “lowest observed” với “statistically superior”, báo effect size và uncertainty theo cùng thiết kế. Nếu muốn tách đóng góp rainfall, thêm ablation giữ cùng loss/siêu tham số bên cạnh so sánh pipeline được tuning riêng. Bài hiện đã thừa nhận confounding do tuning riêng; cần thực nghiệm để củng cố.

### A04 — Moderate — Bootstrap rút ngắn block tạo trọng số quan sát không đều

**ĐÃ XÁC MINH.** Vị trí: §2.5, §3.2; `run_analysis.py` dòng 83–96, đặc biệt dòng 88. Mỗi vị trí bắt đầu được chọn đều, nhưng block bị cắt ở cuối đoạn. Với chuỗi [a,b,c], block 2, tập block là [a,b], [b,c], [c]; số lần được chứa là 1,2,2. Với dữ liệu test thực có ba đoạn dài 536/614/1.010 giờ, số lần được chứa biến thiên 1…B.

**Hậu quả:** bootstrap không có trọng số marginal đồng đều; có hiệu ứng biên lên tâm và độ rộng CI. Ở B=168, H1 có mean gốc +63,41 nhưng trung bình bootstrap rút ngắn trong kiểm tra mới khoảng +13,01 m³. H1 vẫn không được hỗ trợ và H2 vẫn có hướng cải thiện trong các sensitivity đã chạy; **không có bằng chứng đảo ngược hai kết luận đó do lỗi này**.

**Khắc phục:** mô tả đúng estimand và cơ chế resampling; kiểm tra simulation coverage dưới các cấu trúc phụ thuộc phù hợp. Circular blocks trong từng contiguous run đã được dùng làm đối chiếu nhưng tạo nối vòng nhân tạo và cũng không tự động giải quyết nonstationarity; không coi đó là bản sửa đã được xác nhận. Cân nhắc resampling theo event/run hoặc phương pháp time-series đã có căn cứ và kiểm tra độ nhạy block length.

### A05 — Major — High-volume evidence có rất ít đơn vị sự kiện

**ĐÃ XÁC MINH.** Vị trí: Abstract, §3.1, §3.3, Table 2, §4.2. 81 hàng nằm trong năm đoạn với 11/7/26/24/13 cửa sổ. Các đoạn 4 và 5 gần nhau theo thời gian, chưa thể xem là hai trận mưa độc lập.

| Đoạn (UTC) | n cửa sổ | Coverage mean24 pooled |
|---|---:|---:|
| 27/11/2024 13:00–23:00 | 11 | 0% |
| 19/12/2024 00:00–06:00 | 7 | 0% |
| 31/12/2024 14:00–01/01/2025 15:00 | 26 | 7,69% |
| 06/01/2025 10:00–07/01/2025 09:00 | 24 | 16,67% |
| 07/01/2025 22:00–08/01/2025 10:00 | 13 | 100% |

**Hậu quả:** coverage gộp phụ thuộc lớn vào thành phần sự kiện. Bỏ từng đoạn cho coverage từ **8,82% đến 30,91%**. Cửa sổ không chồng lấn theo 12 pha chỉ còn 179–181 mẫu/pha và 6–8 high samples, high coverage 14,29–33,33%. Vấn đề undercoverage vẫn thấy rõ mô tả, nhưng không thể suy tần suất trong quần thể từ 81 như 81 phép thử độc lập.

**Khắc phục:** đưa bảng event vào supplement; định nghĩa event thủy văn bằng rainfall/dry separation trước phân tích; tích lũy thêm sự kiện hoặc hạn chế suy luận. Không tự đưa một effective n duy nhất chưa có mô hình phụ thuộc. Bài đã cảnh báo số event ít, nhưng chưa có báo cáo từng event để người đọc đánh giá.

### A06 — Moderate — Coverage theo outcome không đồng nhất với calibration có điều kiện theo thông tin đầu vào

**ĐÃ XÁC MINH về định nghĩa.** Vị trí: H3, §2.5, §3.3, §4.2. High-volume được xác định bằng **Y tương lai**; wet state được xác định bằng mưa quá khứ. Hai loại conditioning này khác nhau.

**Hậu quả:** độ phủ thấp trên nhóm chọn theo Y không tự chứng minh vi phạm một bảo đảm conditional-on-X, cũng không cung cấp nhóm vận hành biết trước tại issue time. Bài đã nói nhóm high là retrospective, đây là điểm tốt; Discussion cần giải thích hệ quả thống kê rõ hơn. Ngay cả khoảng có marginal coverage đúng cũng không buộc có 90% coverage trong mọi đuôi Y.

**Khắc phục:** giữ high-volume như stress diagnostic; thêm các nhóm định trước từ thông tin sẵn có, nếu có đủ mẫu. Khi muốn early-warning evaluation, phải dự báo exceedance và đánh giá calibration/discrimination của xác suất vượt ngưỡng, không dùng nhãn Y như đầu vào triển khai.

### A07 — Moderate — Quantile radius lệch một order statistic so với rank dự kiến

**ĐÃ XÁC MINH.** Vị trí: §2.5 và `run_analysis.py` dòng 80–81. `np.quantile(scores, ceil((n+1)*0.9)/n, method='higher')` dùng cách đánh chỉ số của NumPy, không lấy trực tiếp phần tử thứ k của scores đã sắp xếp. Với n=2.089, k=1.881 nhưng mã lấy phần tử **1.882**.

**Tác động thực:** mean24 radius hiện 7.022,79 m³; lấy đúng order statistic k cho 6.946,73 m³. Coverage toàn test thay 87,50% → **87,13%**. Đây là sai khác nhỏ, không giải thích high-volume undercoverage nghiêm trọng. Bản Methods mô tả đúng mã hiện tại nên không có mâu thuẫn code–text; vấn đề là cách gọi rank adjustment và cách triển khai nếu chủ ý là conformal order statistic chuẩn.

**Khắc phục:** dùng `k = ceil((n+1)*(1-alpha))`, lấy `np.sort(scores)[k-1]` khi k≤n; quy định riêng trường hợp k>n và n=0. Thêm test với vector tăng dần, ties và subgroup nhỏ. Tính lại tất cả khoảng và bảng sau sửa. Không suy ra coverage guarantee cho chuỗi phụ thuộc chỉ từ việc sửa rank. Xem quy ước [NumPy quantile](https://numpy.org/doc/stable/reference/generated/numpy.quantile.html).

### A08 — Major — Literature chưa đủ để bảo vệ đóng góp gần chủ đề nhất

**ĐÃ XÁC MINH sự thiếu vắng trong bản thảo; CHƯA THỂ XÁC MINH tính mới tuyệt đối.** Vị trí: Introduction, §4.3, References; báo cáo novelty matrix. Bài chỉ có bảy tài liệu tham khảo. Số lượng nhỏ tự nó không phải lỗi; thiếu các công trình cụ thể mới là vấn đề.

- **Pearson et al. (2025), *Diffusion-based Time Series Forecasting for Sewerage Systems***: có dự báo sewer level, hiệu chỉnh conformal, chia calibration theo wet/dry và đánh giá coverage/width. Khác target volume và khác dataset, nhưng rất gần đóng góp conditional reliability/wet–dry của bài. Đã đọc bản hội nghị bốn trang; không chỉ suy từ tiêu đề. [Bản gốc](https://arxiv.org/pdf/2506.08577).
- **Lee & Lee (2026), *Adaptive Conformal Prediction for Full-Scale Plant pH Forecasting under Process Drift***: pH công nghiệp khác inflow, nhưng trực tiếp xét undercoverage dưới drift và so sánh static/adaptive intervals. Đây là conference contribution ngắn, cần mô tả đúng mức độ chứng cứ. [PMLR](https://proceedings.mlr.press/v329/lee26a.html).
- **Abdullah A. Alsumaiei (2026), *Regularized and explainable machine learning framework for anthropogenic–climate coupled prediction of wastewater influent in hyper-arid urban utilities***: metadata DOI, tác giả và tiêu đề đã kiểm tra; monthly target/khí hậu khác, chưa đọc được toàn văn nhà xuất bản nên chỉ là ứng viên cần rà soát, không dùng để khẳng định trùng đóng góp. [DOI](https://doi.org/10.2166/wst.2026.205). Metadata được lưu trong `reference_metadata.json`.

**Hậu quả:** phần đóng góp còn có thể bị xem là ghép các thực hành đã biết trên một bộ dữ liệu. Không được quảng bá wet/dry calibration hoặc cảnh báo marginal coverage như ý tưởng mới.

**Khắc phục:** cập nhật bảng overlap theo target, data, available information, calibration, event evaluation và validation. Xác định phần khác biệt kiểm chứng được: audit target tích lũy trên dữ liệu DHI gốc, kết hợp thông tin issue-time và reliability; cần chứng minh giá trị thêm bằng robustness, không chỉ thay learner. Duy trì wording có điều kiện, không dùng “first”.

### A09 — Major — Ý nghĩa “hourly mean” và thời điểm có sẵn dữ liệu chưa được xác nhận

**CHƯA THỂ XÁC MINH từ nguồn đã có.** Vị trí: §2.2–2.3, công thức V, toàn bộ diễn giải m³. DHI ghi inflow đơn vị m³/h, hourly resolution, và notebook chỉ cách chuyển múi giờ. Chưa có mô tả được xác thực rằng từng giá trị flow là trung bình đúng một giờ, timestamp là đầu/cuối giờ, và latency bằng không.

**Hậu quả:** phép tổng có đơn vị m³ đúng về mặt đại số; nếu Q là điểm lấy mẫu thay vì mean, đây là xấp xỉ thể tích. Nếu stamped t chưa có sẵn khi issue forecast, thông tin vận hành có thể quá lạc quan dù feature code không dùng t+1.

**Khắc phục:** xin data dictionary/aggregation và latency từ DHI; trước khi có xác nhận, viết “hourly flow-rate observations integrated using a one-hour step” và nêu xấp xỉ. Thử feature delay 1–2 giờ như sensitivity chứ không giả vờ đã biết latency. Đây không phải bằng chứng đã phát hiện leakage trong nguồn DHI.

### A10 — Moderate — Complete-window selection và screening chưa có đánh giá đủ theo chế độ vận hành

**ĐÃ XÁC MINH ảnh hưởng mẫu; CHƯA THỂ XÁC MINH cơ chế missingness.** Vị trí: §2.2, §3.1, §6; `features()` dòng 74. Grid có 11.257 giờ nhưng development hợp lệ chỉ bắt đầu 20/01/2024; điều kiện còn yêu cầu future rain đủ cho oracle để so sánh cùng mẫu. Rain thực không thiếu nên điều kiện future-rain không làm giảm mẫu hiện tại và không có bằng chứng gây leakage số liệu.

**Bằng chứng mới:** bỏ hai screening rules tăng development 12h từ 4.398 lên **4.656** cửa sổ; test vẫn 2.160 và MAE baseline không đổi. Chưa refit toàn mô hình theo QC khác, nên chưa biết tác động vào ranking.

**Khắc phục:** thêm flowchart retention và missingness theo tháng/wet state; sensitivity trên common test với các QC policies đã định; ghi rõ denominator và không điền target thiếu để tăng n. Sensor fault logs cần thiết để xác nhận screening đúng. Không áp kiểm định “MCAR” đơn giản rồi coi đã giải quyết missingness theo thời gian.

### A11 — Major — Trạng thái private không đáp ứng tuyên bố truy cập mở hiện tại

**ĐÃ XÁC MINH tại 10/11/2026.** Vị trí: Code Availability, Open Science, README và đường dẫn repository. GitHub API qua kết nối xác thực trả `private: true`, `visibility: private`; release v0.1.0 vẫn tồn tại và không phải draft. Tất cả 16 URL raw không xác thực trả 404.

**Hậu quả:** phản biện hoặc độc giả không được cấp quyền không tải mã/gói từ link trong paper. Hồ sơ 09/11 về tải thành công không chứng minh khả năng truy cập ở ngày audit. Không suy đoán ai đã thay quyền hoặc vì sao.

**Khắc phục:** trước khi nộp, tác giả quyết định public release hoặc cấp anonymous reviewer access phù hợp; kiểm tra bằng phiên không đăng nhập. Nếu chưa public, viết trung thực “available to reviewers…” theo cơ chế thực có. Đưa phiên bản cuối lên archive bền vững nếu chọn open science; DOI phần mềm là khuyến nghị, không phải điều kiện để nghiên cứu tự động hợp lệ. Audit này không đổi quyền repository.

### A12 — Major — Script so sánh có thể báo PASS mà không kiểm tra tệp nào

**ĐÃ XÁC MINH BẰNG PHÉP CHẠY.** Vị trí: `verification/compare_reproduction.py` dòng 3–4,15; ZIP và hồ sơ reproduction. Script hard-code `D:/P2`, loop qua `baseline_results/*.csv` và luôn ghi `status: PASS`. Thư mục baseline_results không có trong ZIP phát hành. Khi baseline rỗng/không tồn tại, vòng lặp không chạy nhưng tiến trình vẫn exit 0 với `csv_comparisons: []`.

**Hậu quả:** người tái hiện có thể nhận bảo đảm rỗng. **Điều này không phủ nhận hồ sơ lần chạy trước có 13 so sánh cụ thể**, cũng không chứng minh các con số đó bị bịa. Nó làm yếu công cụ xác nhận dành cho người tái lập sau này.

**Khắc phục:** dùng CLI `--reference`/`--candidate`; bắt buộc đúng danh sách 13 tệp, không rỗng, tồn tại hai bên, schema và số hàng hợp lệ; fail trước khi ghi PASS nếu thiếu bất kỳ mục nào. Phát hành expected outputs hoặc expected digest của bảng đã chuẩn hóa. Thêm test âm: missing reference, empty reference, missing candidate, altered numeric cell, reordered columns. Giữ report cũ như bằng chứng lịch sử thay vì ghi đè.

### A13 — Moderate — Chưa chứng minh độc lập thời điểm prespecification

**CHƯA THỂ XÁC MINH.** Vị trí: Protocol heading, §2.3, Code Availability và Open Science, Markdown dòng 61,180,200. Protocol và execution log tự ghi rằng được tạo trước fitting; không có registry hoặc lịch sử commit công khai trước kết quả trong hồ sơ đã xét. Release chứa code/protocol/results cùng thời điểm.

**Hậu quả:** không đủ chứng cứ ngoài lời tự mô tả để bảo đảm H1–H3, grid và horizon thực sự prespecified. Không có căn cứ quy kết HARKing; cũng không nên gọi đã audit xác nhận prespecification.

**Khắc phục:** nếu có nhật ký có dấu thời gian đủ mạnh, cung cấp và phân biệt nguồn; nếu không, đổi wording thành documented exploratory protocol. Mọi stress test audit ngày 10/11 phải được đánh dấu hậu kiểm. Từ bây giờ đăng ký/commit kế hoạch mới trước fitting trên dữ liệu hoặc origin chưa dùng.

### A14 — Moderate — Verification và lưu trữ chưa bao phủ toàn bộ chuỗi lập luận

**ĐÃ XÁC MINH.** Vị trí: `verify_results.py`, requirements và supplement. Verifier gốc chủ yếu kiểm tra MAE/RMSE, chronology và một perturbation/horizon; không kiểm tra order statistic quantile, wet/dry recalibration, code path empty baseline hoặc mismatch của câu trong paper. Calibration predictions và fold-level CV scores chưa được lưu thành bảng riêng; có thể tạo lại bằng refit nhưng khó kiểm tra trực tiếp. Không bắt buộc phải lưu pickle model nếu pipeline tái tạo được.

**Hậu quả:** một regression về calibration hoặc lựa chọn mô hình có thể lọt qua kiểm tra PASS. Rerun cùng mã cũng có thể tái tạo cùng lỗi logic.

**Khắc phục:** thêm test cấp dữ liệu nguồn, quantile và invariants; lưu calibration predictions, fold time ranges/scores, selected params, version và lệnh chạy. Viết bảng claim→file→column→calculation để tự sinh phần số liệu trong manuscript. Không nói “all claims verified” chỉ vì verifier thành công.

### A15 — Moderate — Dựng paper chưa được đóng gói tái lập xuyên môi trường

**ĐÃ XÁC MINH từ mã/phụ thuộc.** Vị trí: `paper/build_paper_pdf.py`, `requirements-clean-lock.txt`. Builder dùng ReportLab nhưng lock phân tích không có reportlab; font hard-code `C:/Windows/Fonts/times*.ttf`. Công thức LaTeX được thay bằng câu chữ bằng quy tắc đặc biệt. Không có lệnh build manuscript trong README chính.

**Hậu quả:** tái tạo numerical results khác với tái tạo bản PDF; người dùng Linux hoặc môi trường chỉ cài lock có thể không dựng paper. Đây không làm metric sai, nhưng hạn chế tuyên bố reproducible publication package.

**Khắc phục:** tách `requirements-analysis` và `requirements-docs`, dùng font phân phối được với fallback, document lệnh build và kiểm tra từ thư mục mới. Công thức cần typeset nhất quán; không hard-code một câu thay thế mọi equation block. Bổ sung phiên bản renderer và manifest tài liệu.

### A16 — Minor — Bảng và hình chưa được tích hợp tốt vào thân bài

**ĐÃ XÁC MINH.** Vị trí: PDF Table 2 tr. 5–6; Figure 1–5 tr. 10–14; toàn thân bài. Không thấy lời gọi Figure 1–5 trong phần nội dung chính; chỉ có danh mục caption. Table 2 bị tách sau dòng HGB historical wet/dry, hai dòng oracle sang trang 6. Header lặp nên vẫn đọc được, không mất dữ liệu.

**Hậu quả:** người đọc phải tự nối phân tích với đồ thị. Khoảng trắng lớn ở phần figures không phải lỗi khoa học nhưng có thể không phù hợp template.

**Khắc phục:** gọi từng hình ở đoạn liên quan; giữ Table 2 trên một trang hoặc dùng “continued”; kiểm tra hướng dẫn tạp chí trước khi đặt hình cuối. Figure 2/3 dùng tên biến nội bộ, nên thay bằng nhãn tự giải thích và thống nhất tên oracle giữa bảng/hình.

### A17 — Minor — Nhãn/giải thích hình và trình bày phương trình cần chuẩn hóa

**ĐÃ XÁC MINH.** Vị trí: Fig.1 tr.10; equation tr.3; Fig.3 tr.12; Fig.5 tr.14. Rainfall nguồn là accumulated precipitation mm trên mỗi giờ; nhãn mm/h có thể hiểu là intensity, nên ghi rõ “hourly precipitation (mm)”. Fig.1 không ghi tên ba partition trực tiếp cạnh biên; Fig.3 nối các model rời rạc bằng đường có thể gợi thứ tự liên tục; Fig.5 chỉ là perturbation sensitivity.

**Khắc phục:** chuẩn hóa đơn vị/timestamp trong caption, ghi phase labels; dùng grouped dots/bars cho categorical model; giữ mô tả SD không phải CI ở Fig.5. Viết phương trình có chỉ số và định nghĩa rõ hourly-rate integration. Không gọi hình có SD bar là bằng chứng significance.

### A18 — Minor — Hồ sơ tác giả và các tuyên bố nộp bài chưa hoàn chỉnh

**ĐÃ XÁC MINH thiếu mục; CHƯA THỂ XÁC MINH nội dung cần điền.** Vị trí: title page và sau Conclusions. Đã có tên/affiliation đúng thông tin cung cấp; chưa có corresponding email, funding statement, conflicts of interest, CRediT/author contributions và xác nhận tác giả đã duyệt. ORCID tùy yêu cầu, không phải điều kiện bắt buộc chung. AI disclosure có nhưng còn viết “must review”, tức trách nhiệm duyệt vẫn đang chờ thực hiện.

**Khắc phục:** tác giả cung cấp/duyệt từng statement; không tự điền “no funding/no conflict” khi chưa xác nhận. Ghi công cụ AI và phạm vi hỗ trợ theo journal policy; AI không là đồng tác giả. Dữ liệu vận hành ẩn danh không tự động yêu cầu IRB người tham gia, nhưng cần mô tả nguồn, quyền dùng và không đo mới. Không tạo chứng nhận ethics miễn trừ không có thật.

### A19 — Minor — Tài liệu tham khảo và bản lưu có bất nhất biên tập

**ĐÃ XÁC MINH.** Vị trí: References tr.8–9; supplement README/execution log; reference catalogue. Bảy nguồn chính tồn tại; không phát hiện DOI bịa trong bảy mục. References [4]/[5] ghi et al. rồi hướng người đọc sang BibTeX để xem author metadata; chưa theo style tạp chí cụ thể. Danh mục BibTeX có tài liệu ứng viên ngoài bảy nguồn được trích trong paper; không phải ghost citation nếu được ghi là catalogue, nhưng phải phân biệt rõ.

Các README/log ban đầu còn nói chưa có public publication, trong khi release và README mới mô tả đã phát hành. Đây là bản ghi lịch sử, không nhất thiết gian dối, nhưng chưa có chỉ dẫn đủ rõ trong archive về tài liệu nào là trạng thái hiện hành.

**Khắc phục:** dùng reference manager và style journal; tách cited references khỏi search catalogue; thêm `STATUS.md`/changelog trong gói phát hành và đánh dấu tài liệu ban đầu là historical. Không sửa log cũ để che lịch sử. Danh sách Bøhn/Eidnes/Jonassen **đúng** ở cả arXiv v1/v2; cụm tự động “and 1 other authors” trên trang không phải căn cứ kết luận sai tác giả.

## 5. Kiểm định từng phần của paper

| Thành phần | Đánh giá riêng | Hành động |
|---|---|---|
| Title | Nêu target, horizon, single plant và audit; không hứa công nghệ xử lý mới. Hơi dài nhưng chính xác. | Có thể giữ; không thêm “novel”, “robust” hoặc “operationally validated”. |
| Author/affiliation | Khớp dữ liệu tác giả cung cấp; chưa có email/approval. | A18. |
| Highlights, cả 5 ý | Có cơ sở trong cấu hình gốc; ý baseline thắng phải giữ giới hạn cấu hình/holdout. | Sửa sau robustness, không dùng stress test như kết quả xác nhận. |
| Abstract | Có mục tiêu, nguồn, phương pháp, n, kết quả, hạn chế; 228 từ theo bản gốc. Chưa nói loss, chưa định lượng event heterogeneity; dùng “supported” cần mềm hơn. | Giữ số liệu gốc nếu báo v0.1.0; cập nhật sau phân tích mới. |
| Keywords | Phù hợp; “wastewater treatment” rộng hơn nội dung inflow. | Cân nhắc wastewater inflow forecasting, hydrological loading; không cần nhồi từ khóa. |
| Introduction | Research problem có ý nghĩa; đã thừa nhận prior work. Gap chưa được so với Pearson/Lee và chưa có bảng differentiating contribution. | A08; thêm đường nối từ inflow volume tới quyết định nhưng không suy benefits. |
| Literature review | Tích hợp trong Introduction/Discussion là chấp nhận được cho original research; không bắt buộc chương riêng. | Tổng hợp theo target–information–uncertainty–validation, không chỉ tăng số trích dẫn. |
| Objectives/RQs | Ba câu hỏi chính thống nhất với H1/H2/H3; proposal có RQ4 sensitivity. | Ghi explicit exploratory status và pipeline-level estimand. |
| Framework | Có trong proposal; paper diễn đạt bằng lời, chưa có sơ đồ. Thiếu biến network/storage là giới hạn đã biết. | Một sơ đồ thông tin có issue-time boundary sẽ hữu ích, không bắt buộc một lý thuyết mới. |
| Hypotheses | H1/H2 định lượng rõ; H3 mô tả outcome tail, không phải test confirmatory có power. | Nêu model/phạm vi; không suy “không có hiệu ứng” từ CI chứa 0. |
| §2.1 Data provenance | DOI, source v1, số dòng và phân biệt raw/processed tốt. | Xác nhận ý nghĩa aggregation, cập nhật accessibility. |
| §2.2 QC | Quy tắc rõ, không xóa extreme tùy ý; có missingness warning. | A10, bảng retention và sensitivity. |
| §2.3 Target/features | Công thức và m³ có logic; explicit oracle tốt. Hourly mean/latency chưa xác minh. | A09; ghi giả định thay vì kết luận nguồn. |
| §2.4 Models/validation | Split chronological, fit imputation trong folds, tắt random early stopping là phù hợp. | A01/A02; báo loss và repeated origins. |
| §2.5 Intervals/statistics | Không hứa exchangeability/conformal guarantee là điểm mạnh. | A03–A07; xác định uncertainty estimand. |
| §3.1 Data results | Sample counts, dates, thresholds kiểm tra được. | Thêm retention theo calendar và bảng event. |
| §3.2 Point results | Table 1 khớp; ranking đúng trong bảy cấu hình gốc. | Hạn chế claim; robustness và paired baseline comparison. |
| §3.3 Reliability | Coverage đúng; pooled/wet-dry có trade-off rõ. | Báo width + interval score cho mọi phương pháp, không chọn theo coverage đơn lẻ. |
| §3.4 Sensitivity | 6/24 giờ có chạy thật; residual ACF mô tả hợp lý; group shift không causal. | Thêm loss/calendar/QC/origin; không so MAE khác horizon như cùng target. |
| §4.1 Discussion | Đã tách oracle và weather forecast thật; đã thừa nhận tuning riêng. | Không diễn giải mức gain 73,1% như information value độc lập cấu hình. |
| §4.2 Discussion | Nhìn ra undercoverage thực trên nhóm high. | A05/A06; phân biệt tail diagnostic và guarantee. |
| §4.3 Novelty | Có restraint, không nhận đổi thuật toán là novelty. | So sánh trực tiếp công trình bị bỏ sót, tăng evidence của đóng góp. |
| Practical implications | Không hứa tiết kiệm điện, tank sizing, removal; ranh giới khoa học tốt. | Giữ; bổ sung decision loss chỉ khi có dữ liệu capacity/cost. |
| Limitations | Rộng và trung thực; không thay thế các sensitivity có thể thực hiện. | Thêm loss sensitivity và private-access state; không chỉ liệt kê thiếu dữ liệu. |
| Conclusions | Tương thích kết quả gốc, nhưng chưa vững nếu đọc như ranking chung. | Giữ cấu hình/holdout-specific; bỏ mọi khẳng định ưu việt tổng quát. |
| Data Availability | DOI nguồn có thật, dữ liệu non-commercial được phân biệt. | Thêm versioned analysis archive và timestamp semantics. |
| Code Availability | Có code/lock/hash; private và verifier lỗi cản trở access/reproducibility. | A11/A12/A14/A15. |
| Open Science/AI | Có disclosure và không giả DOI; không preregistered. | Đổi wording prespecification nếu không có bằng chứng; hoàn tất human approval. |
| References | 7/7 nguồn tồn tại; các claim cốt lõi phải được đối chiếu nội dung, không chỉ DOI. | A08/A19. |

## 6. Kiểm định riêng từng bảng, hình và phụ lục

| Đối tượng | Kết quả kiểm tra | Sửa cần thiết |
|---|---|---|
| Table 1, tr.5 | Bảy hàng MAE/RMSE/R²/bias phù hợp CSV; unit/n và oracle warning có. | Ghi loss cho learned models hoặc dẫn bảng model spec; thêm paired effects trong supplement. |
| Table 2, tr.5–6 | Coverage pooled đối chiếu trực tiếp; HGB wet/dry refit khớp. n high/wet nêu rõ; dry/all có thể suy nhưng nên ghi đủ. | Width/interval score chưa nằm trong bảng; table split nên xử lý. Không gọi gần 90% là đã calibrated trong quần thể. |
| Figure 1, tr.10 | Timeline/gaps và split boundaries phù hợp dữ liệu. | Ghi tên partition; làm rõ rainfall accumulation; thêm tỷ lệ retained windows. |
| Figure 2, tr.11 | Giá trị MAE all/high phù hợp bảng output; không cắt y-axis tạo cảm giác sai. | Nhãn biến nội bộ cần đổi; thêm n high và cảnh báo event dependence ngay caption đã có n=81 nhưng nên có 5 episodes. |
| Figure 3, tr.12 | Pooled coverage đúng; nominal line rõ, không tự nhận guarantee. | Dùng điểm/cột cho model rời rạc; không trộn oracle trong ranking triển khai. |
| Figure 4, tr.13 | Cửa sổ đầu 14 ngày theo quy tắc định trước, không thấy lựa chọn theo sai số. | Gọi hình ở §3.3/3.4; cân nhắc thêm baseline; đây là illustration, không đại diện tất cả events. |
| Figure 5, tr.14 | Nhóm flow/rain/calendar/other-weather và mean±SD khớp cách sinh; SD không phải CI. | Giữ chữ sensitivity; không diễn giải predictor causality hoặc universal importance. |
| Protocol/proposal | Câu hỏi và model grid nhất quán tương đối; protocol nói block permutation trong khi thực thi circular group shift và paper đã diễn đạt đúng hơn. | Cập nhật deviation log; đánh dấu trước/sau phân tích bằng chứng thực có. |
| Review + novelty matrix | Có 10 topic và suitability có điều kiện, không giả rằng mọi dataset đã audit. | Thêm prior work mới; catalogue không thay được full-text review. |
| Computed tables/CSV | Các phép tính chính khớp; chứa nhiều subgroup/horizon ngoài paper. | Bản đồ claim→table và báo exploratory multiplicity; không chỉ chọn các kết quả thuận lợi. |
| Source data/metadata | Hai ZIP checksum khớp; raw đã là hourly, không phải sensor-frequency. | Data dictionary về sensor/aggregation và truy nguyên đơn vị. |
| Code + locks | Script phân tích có seed/dependency; chạy được các refit audit trong env hiện có. | Fail-closed verifier, portable paths, tách doc dependencies. |
| Reproduction report/log | Có 13 kết quả so sánh trước đó, không có bằng chứng giả trong audit. | Chặn PASS rỗng và publish expected files/digests; log cũ gắn trạng thái lịch sử. |
| Supplement ZIP | 87 mục, manifest 86, CRC không lỗi, hashes đã kiểm tra không mismatch. | Không có baseline_results; metadata/status còn phân tán; cần package index và command tái lập ngoài D drive. |

Không có appendix được đánh số chính thức trong PDF; phần phụ trợ nằm trong ZIP. Không nên gọi “all appendices reviewed scientifically” cho mọi dòng metadata hoặc toàn văn từng bài trong search catalogue. Phạm vi đọc và phép kiểm tra cụ thể đã nêu ở §1.

## 7. Trích dẫn, tính mới và liêm chính

| Ref. của manuscript | Xác minh tồn tại/bibliography | Mức kiểm tra nội dung và lưu ý |
|---|---|---|
| [1] Yang & Li 2025, DOI 10.1021/acsestwater.4c01047 | Tên, hai tác giả, năm, journal, tập/trang khớp ACS/Crossref. | Bibliometric review phù hợp bối cảnh chung; không đủ riêng để chứng minh operational utility hoặc gap hẹp. [ACS](https://pubs.acs.org/doi/10.1021/acsestwater.4c01047). |
| [2] DHI 2025, 10.5281/zenodo.15301164 | Record v1, tác giả tổ chức, nguồn data xác nhận. | README/notebook cho thấy perfect observed rain được nói rõ; không cáo buộc tác giả DHI giấu leakage. License README có chữ không nhất quán, metadata Zenodo BY-NC là cơ sở đang dùng. [Zenodo](https://zenodo.org/records/15301164). |
| [3] Sonnenschein & Ziel 2023 | DOI/tác giả/journal/article ID khớp. | Đã có probabilistic inflow và rain forecast; không thể nhận ý tưởng này là mới. Không rerun mô hình của họ trong audit. [Wiley](https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2022WR033826). |
| [4] González Barberá et al. 2025 | DOI/tên/tác giả/năm khớp nhà xuất bản. | WWTP inflow/rain forecasting khác target/sampling; không so R² trực tiếp giữa bài. [Water](https://www.mdpi.com/2073-4441/17/22/3225). |
| [5] Roberts et al. 2017 | DOI/tên/năm/trang khớp. | Hỗ trợ structured CV; không tự xác nhận bootstrap tùy biến của bài. [Ecography](https://doi.org/10.1111/ecog.02881). |
| [6] Bøhn, Eidnes, Jonassen 2024 | Ba tác giả đúng; v1 2024, v2 2025; preprint được ghi đúng là preprint. | Abstract trực tiếp mô tả temporal transfer và temperature shift; không bằng chứng rằng drift gây toàn bộ HGB failure của DHI. [arXiv v2](https://arxiv.org/abs/2412.14030v2). |
| [7] Xu & Xie 2023 | Tên tác giả/title/PMLR/pages khớp. | SPCI là phương pháp khác; paper đã nói không triển khai SPCI, đúng. [PMLR](https://proceedings.mlr.press/v202/xu23r.html). |

Trong đợt kiểm tra metadata mở rộng, một yêu cầu Crossref cho DOI 10.1016/j.cej.2023.143073 không thành công; DOI đó thuộc catalogue đề tài ứng viên, không phải bảy references của paper. Không suy ra nó không tồn tại từ lỗi truy cập. `reference_metadata.json` lưu kết quả từng yêu cầu. Chưa audit full text toàn bộ literature catalogue hoặc chạy plagiarism database; không có cơ sở cấp chứng nhận “không đạo văn”.

Nghiên cứu tái sử dụng dataset là hợp lệ khi nguồn/giấy phép rõ và câu hỏi/đóng góp phân biệt được. Trùng dataset DHI **đã xác nhận**; trùng application inflow/rain **đã xác nhận**; trùng lớp model/calibration **có phần rõ**; trùng toàn bộ đóng góp tích lũy-volume audit **chưa thể kết luận**. Việc không tìm thấy bài giống hoàn toàn không chứng minh tính mới tuyệt đối.

## 8. Quyết định về giả thuyết và ý nghĩa kỹ thuật

**H1:** Với hai cấu hình squared-error HGB gốc, dữ liệu không hỗ trợ cải thiện ổn định khi thêm past meteorology. CI chứa 0 không chứng minh hiệu ứng bằng 0 hay hai pipeline tương đương. Không suy rộng sang loss khác, thời kỳ khác hoặc nhà máy khác.

**H2:** Oracle HGB tốt hơn historical HGB gốc trên holdout ở 12 giờ; hướng chênh lệch ổn định trong các bootstrap sensitivity đã xét. Gain là pipeline-specific và comparator historical rất yếu. Không phải causal value of rainfall, không phải giá trị của dự báo thời tiết thực, cũng không là mathematical upper bound. Bản thảo đã thừa nhận nhiều giới hạn này, nên sửa trọng tâm hơn là bỏ toàn kết quả.

**H3:** High-volume undercoverage của mean24 được quan sát thực và còn thấy ở cả 12 pha nonoverlap. Đây là evidence mô tả hữu ích; chưa đủ để ước lượng population reliability, nhất là khi conditioning trên Y và chỉ năm đoạn.

**Ý nghĩa môi trường/công nghệ:** bài nói về hydraulic input forecasting của nhà máy nước thải, không đo hiệu suất xử lý, chất ô nhiễm, energy, storage hoặc overflow. Không thể dùng kết quả hiện tại để khẳng định “tối ưu công nghệ xử lý” hoặc “giảm chi phí vận hành”. Việc không có thí nghiệm lab không làm một computational paper vô giá trị; đóng góp cần đứng vững ở evaluation design, reliability và khả năng tái kiểm tra.

## 9. Các câu nên sửa trong bản thảo

Các gợi ý dưới đây không thay thế việc chạy lại khi sửa phương pháp; giữ phân biệt bản gốc và audit.

| Vị trí | Đề nghị wording tiếng Anh |
|---|---|
| §2.3, hourly mean chưa xác nhận | “We integrated the archived hourly flow-rate observations using a one-hour time step. Whether each observation represents an exact hourly mean, and its measurement availability time, requires confirmation from the data provider.” |
| §2.4, model loss | “The original HGB configurations used the squared-error training loss and were selected by temporal cross-validation MAE. Sensitivity to training loss and calendar representation was not included in the original grid.” |
| §3.2, ranking | “The 24-hour moving-average baseline had the lowest observed MAE among the historical-information configurations included in the original experiment.” |
| §4.1, audit stress results | “Post hoc audit experiments revealed substantial sensitivity to the training loss and annual calendar features. These experiments challenge broad interpretations of model ranking and require validation on previously unused temporal origins or data.” |
| §4.2, outcome subgroup | “The high-volume analysis conditions retrospectively on the realized target. It assesses tail-event performance and should not be interpreted as a test of a conditional-on-covariates coverage guarantee.” |
| Open science, nếu không có chứng cứ pre-fit độc lập | “An exploratory analysis protocol is included in the package. It was not independently preregistered, and the package alone does not establish the chronology of all analysis decisions.” |
| Code availability ở trạng thái audit | “The analysis repository is currently private. Reviewer access and a persistent public release must be arranged before describing the code as publicly available.” |

## 10. Điều kiện trước khi nộp và định hướng tạp chí

**Ưu tiên bắt buộc trước nộp:** xử lý A01/A02 về robustness; cập nhật A08 về novelty; làm rõ A09 về target/latency; xử lý A11/A12 về access và PASS rỗng; sửa quantile và đánh giá bootstrap; bổ sung event/conditional analysis; hoàn thiện author statements. Nếu không lấy được data mới, phải định vị bài là exploratory single-plant audit và giảm mức kết luận tương ứng.

| Nhóm việc | Sản phẩm cần đạt | Tiêu chí hoàn thành |
|---|---|---|
| Phương pháp | Protocol revision và deviation log | Loss, features, origin, metric và interval methods quyết định trước fitting tiếp; ghi rõ phần hậu kiểm. |
| Validation | Multiple-origin tables + chưa dùng test cuối nếu có | Mỗi origin purge đúng, calibration riêng; báo tất cả origin, không chọn mùa tốt. |
| Statistics | Bootstrap justification, corrected quantile, event tables | Test âm cho rank/empty files; uncertainty có estimand và assumptions; không iid hóa overlapping windows. |
| Baselines | Mean24/persistence/robust HGB + matched information ablations | So sánh paired, không phóng đại gain so với comparator yếu. |
| Data provenance | Source clarification hoặc wording giả định | Xác nhận hourly aggregation/time availability; nếu chưa có thì nói rõ chưa biết. |
| Open science | Anonymous access, versioned package, portable reproduction | Người không đăng nhập tải được khi claim public; rerun từ đường dẫn mới; thiếu expected files phải FAIL. |
| Manuscript | Figures cited, tables gọn, reference style, declarations | Số trong abstract/results sinh từ outputs cuối; human author approval được thực hiện. |
| Independent review | Một người ngoài chuỗi tạo bài đọc code và lập luận | Đánh giá novelty/statistics thực, không chỉ kiểm tra chạy được. |

**Journal of Hydroinformatics:** hướng chủ đề có vẻ phù hợp nhất với forecasting/evaluation, nhưng đây là đánh giá chuyên môn về fit, không bảo đảm qua desk review. **Water Science & Technology:** cần lý giải giá trị vận hành WWTP rõ hơn nhưng không bịa benefits. **Environmental Modelling & Software:** framework/methodological generality hiện còn yếu nếu chỉ single-plant case. Hướng technical note/reproducibility/case study có thể thực tế hơn full methodological advance, tùy loại bài tạp chí thực sự nhận.

Hướng dẫn tác giả IWA tại các đường dẫn đã thử không truy cập được trong đợt audit; vì vậy **chưa xác minh compliance từng tạp chí hoặc quartile hiện hành**. Không dùng IF/SJR hoặc thứ hạng tổng hợp cũ để xác nhận “đạt Q1/Q2”. Cần chọn journal cụ thể rồi kiểm tra scope, article type, word limit, highlights, reference style, data/AI policy và prior-publication policy tại thời điểm nộp. Các hướng dẫn [Water Environment Research](https://onlinelibrary.wiley.com/page/journal/15547531/homepage/author-guidelines) và [Environmental Data Science](https://www.cambridge.org/core/journals/environmental-data-science/information/author-instructions/preparing-your-materials) được dùng làm tham chiếu về minh bạch, không áp thay cho tạp chí đích.

## 11. Tệp bằng chứng và cách chạy lại audit

Tất cả hồ sơ tại `D:/P2/audit`; bản báo cáo và gói tải xuống được sao lưu trong outputs của chat. Các file chính:

- `full_audit.py`, `audit_additional.py`: mã kiểm tra; dùng Python env phân tích hiện tại. Các đường dẫn D:/P2 được ghi rõ vì đây là harness audit cục bộ, không được quảng bá như bản phát hành portable.
- `audit_results.json`: 17 nhóm kiểm tra, hashes nguồn, refits, quantile, QC, episodes, archive checks và HTTP failures.
- `metric_checks.csv`, `pooled_interval_checks.csv`, `refit_calibration_checks.csv`: tính lại chỉ số.
- `model_refit_and_stress_tests.csv`: ba HGB refit và ba stress tests; mọi stress test là hậu kiểm.
- `bootstrap_audit.csv`, `nonoverlap_sensitivity.csv`, `high_volume_episodes.csv`, `inner_folds.csv`, `summary_diagnostics.json`.
- `empty_baseline_test.json` và thư mục `empty_baseline_reproducer`: bằng chứng PASS với zero comparisons.
- `github_access_status.json`: trạng thái private xác minh qua kết nối GitHub.
- `reference_metadata.json`: kết quả Crossref, gồm lỗi truy cập; `external_sources.md`: nguồn kiểm chứng bên ngoài và giới hạn.
- `archive_inventory.txt`: danh mục toàn gói; `page_*.txt`, `contact_*.png`: bằng chứng đọc PDF/visual QA.

Lệnh kiểm tra trong môi trường hiện tại: `D:\P2\.venv\Scripts\python.exe D:\P2\audit\full_audit.py`. Harness cần source package tại D:/P2 và mạng cho phần kiểm tra public/metadata; không đổi scientific sources. Script bổ sung kiểm tra lỗi PASS rỗng và metadata; trạng thái GitHub là quan sát được lưu theo ngày, không phải kết quả live do script đó tạo. Không dùng harness audit như bước sản xuất paper.

**Đánh giá cuối cùng:** có nền tảng nghiên cứu thật và khả năng sửa thành một case study đáng tin. Các lỗi lớn hiện nằm ở sức mạnh bằng chứng, độ nhạy thiết kế và cơ chế kiểm tra/công khai, không phải đã phát hiện bịa số. Chưa có căn cứ chứng nhận bài đủ tiêu chuẩn nộp Q1/Q2 hoặc chắc chắn được nhận. Giữ kết quả âm và nhật ký; sửa bằng phân tích có kế hoạch, không làm đẹp thứ hạng bằng holdout đã xem.


## 12. Bổ sung: kiểm tra GitHub bằng trình duyệt tích hợp

Theo yêu cầu bổ sung của tác giả, đã mở trực tiếp kho trong ChatGPT integrated browser ngày 10/11/2026. Trang chính hiển thị **Private**, 16 tệp và commit da3b755; README có đủ bốn lệnh chạy nhưng vẫn ghi manuscript publicly readable. Release v0.1.0 tồn tại và liên kết đến PDF/ZIP theo tag. Mục Assets chỉ có hai source archives tự động của GitHub; PDF và supplementary ZIP nằm trong repository, không phải custom release assets. Điều này không làm mất tệp, nhưng cần mô tả đúng nơi tải. Trang Actions chuyển tới Get started with GitHub Actions; chưa có bằng chứng workflow tái hiện đã chạy, phù hợp việc README không tuyên bố CI.

Đã mở reproduction.json trên trình duyệt: có 13 đối chiếu cụ thể, không phải report rỗng. Đồng thời đã tải manuscript.pdf và supplementary_v0.1.0.zip từ tag v0.1.0 bằng phiên đăng nhập, đối chiếu SHA-256: **cả hai khớp bản đang audit**. Điều này nối trực tiếp bản thẩm định với gói GitHub; không thay đổi kết luận rằng độc giả không được cấp quyền hiện không truy cập công khai được.

Ảnh bằng chứng: github_private.jpg; các bản chụp DOM có trong github_repository_dom.txt, github_release_dom.txt, github_actions_dom.txt, github_reproduction_dom.txt. Kết quả hash tại browser_download_verification.json. Không sửa quyền truy cập hoặc nội dung trên GitHub.
