"""Package only declared study artifacts; exclude environments, caches and browser state."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    # Current aliases replace historical root files without rewriting prior releases.
    for src,dst in [('manuscript_FINAL.pdf','manuscript.pdf'),('manuscript_FINAL.md','manuscript.md'),
      ('DATA_LICENSE.md','LICENSE_DATA.md'),('requirements.txt','requirements-clean-lock.txt'),
      ('clean_reproduction/reproduction.json','reproduction.json')]:shutil.copy2(ROOT/src,ROOT/dst)
    (ROOT/'PROTOCOL.md').write_text('# Current protocol: v0.2.0\n\nThe original protocol is preserved in provenance/protocol_v0.1.0.md. This revision is retrospective, not preregistered.\n\n'+(ROOT/'PROTOCOL_v0.2.0.md').read_text(encoding='utf8'),encoding='utf8')
    # All nine manuscript references, not the larger unverified discovery catalogue.
    cross=json.loads((ROOT/'sources/verified_crossref.json').read_text(encoding='utf8'));by={x['doi']:x for x in cross}
    refs=[('Yang2025','10.1021/acsestwater.4c01047','2025','ACS ES&T Water','5','511--524'),
      ('Sonnenschein2023','10.1029/2022WR033826','2023','Water Resources Research','59','e2022WR033826'),
      ('GonzalezBarbera2025','10.3390/w17223225','2025','Water','17','3225'),
      ('Roberts2017','10.1111/ecog.02881','2017','Ecography','40','913--929')]
    bib=[]
    for key,doi,year,journal,volume,pages in refs:
        rec=by[doi];authors=' and '.join(a['family']+', '+a.get('given','') for a in rec['authors'])
        bib.append('@article{'+key+',\n  author = {'+authors+'},\n  title = {'+rec['title'][0].replace('\u2010','-')+'},\n  year = {'+year+'},\n  journal = {'+journal+'},\n  volume = {'+volume+'},\n  pages = {'+pages+'},\n  doi = {'+doi+'}\n}')
    bib.extend(['''@misc{DHI2025,
  author = {{DHI}},
  title = {Inflow to a Waste Water Treatment Plant: observations and processed data},
  year = {2025}, publisher = {Zenodo}, version = {1},
  doi = {10.5281/zenodo.15301164}
}''','''@misc{Pearson2025,
  author = {Pearson, Nicholas A. and Cairoli, Francesca and Bortolussi, Luca and Russo, Davide and Zanello, Francesca},
  title = {Diffusion-based Time Series Forecasting for Sewerage Systems},
  year = {2025}, eprint = {2506.08577}, archivePrefix = {arXiv},
  doi = {10.48550/arXiv.2506.08577},
  note = {Version 1; accepted for presentation at the 13th Urban Drainage Modelling Conference}
}''','''@inproceedings{Lee2026,
  author = {Lee, Jongyeop and Lee, Jong Min},
  title = {Adaptive Conformal Prediction for Full-Scale Plant pH Forecasting under Process Drift},
  year = {2026}, booktitle = {Proceedings of the Fifteenth Symposium on Conformal and Probabilistic Prediction with Applications},
  series = {Proceedings of Machine Learning Research}, volume = {329}, pages = {1043--1045},
  url = {https://proceedings.mlr.press/v329/lee26a.html}
}''','''@misc{Bohn2024,
  author = {Bøhn, Eivind and Eidnes, Solve and Jonassen, Kjell Rune},
  title = {Machine learning in wastewater treatment: insights from modelling a pilot denitrification reactor},
  year = {2024}, eprint = {2412.14030}, archivePrefix = {arXiv},
  url = {https://arxiv.org/abs/2412.14030}, note = {Version 2 posted in June 2025}
}''','''@inproceedings{Xu2023,
  author = {Xu, Chen and Xie, Yao},
  title = {Sequential Predictive Conformal Inference for Time Series},
  year = {2023}, booktitle = {Proceedings of the 40th International Conference on Machine Learning},
  series = {Proceedings of Machine Learning Research}, volume = {202}, pages = {38707--38727},
  url = {https://proceedings.mlr.press/v202/xu23r.html}
}'''])
    bib.append('''@misc{SonnenscheinZielData2022,
  author = {Sonnenschein, Björn and Ziel, Florian},
  title = {Wastewater Treatment Plant Inflow Rate, Network Water Levels and Rain Rate for Koeln Weiden, Germany},
  year = {2022}, publisher = {Zenodo}, version = {1.0},
  doi = {10.5281/zenodo.6992694}
}''')
    (ROOT/'references.bib').write_text('\n\n'.join(bib)+'\n',encoding='utf8')
    files=[]
    directories=['data','results','clean_reproduction','figures','sources','provenance','external_data','external_results','external_clean']
    for directory in directories:
        files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts
          and not (directory in ['clean_reproduction','external_clean'] and p.suffix=='.csv')
          and p.name!='radar_forecast.csv')
    allowed={'.py','.md','.html','.pdf','.txt','.json','.csv','.cff','.bib','.log'}
    exclude={'MANIFEST_SHA256.json','release_manifest.json','SHA256SUMS.txt','publication_verification.json'}
    files.extend(p for p in ROOT.iterdir() if p.is_file() and (p.suffix in allowed or p.name=='LICENSE') and p.name not in exclude)
    files=sorted(set(files),key=lambda p:str(p.relative_to(ROOT)))
    manifest={p.relative_to(ROOT).as_posix():sha(p) for p in files}
    (ROOT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
    publication=ROOT/'publication';publication.mkdir(exist_ok=True)
    archive=publication/'supplementary_v0.2.0.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files+[ROOT/'MANIFEST_SHA256.json']:z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
    publish_names=['README.md','CITATION.cff','LICENSE','LICENSE_DATA.md','DATA_LICENSE.md','PROTOCOL.md','PROTOCOL_v0.2.0.md',
      'PROTOCOL_DEVIATIONS.md','CHANGELOG.md','RESPONSE_TO_AUDIT_VI.md','SUPERVISOR_NOTE_VI.md','LITERATURE_MATRIX.md',
      'manuscript.pdf','manuscript.md','references.bib','requirements.txt','requirements-clean-lock.txt','requirements-docs.txt',
      'download_data.py','run_analysis.py','verify_results.py','compare_reproduction.py','configuration_sensitivity.py','bootstrap_diagnostic.py',
      'make_figures.py','write_manuscript.py','extend_manuscript.py','build_paper.py','reproduction.json','claim_evidence_map.csv','audit_resolution_register.csv',
      'external_site.py','verify_external.py','EXTERNAL_SITE_PROTOCOL.md','LIMITATIONS_RESOLVED_VI.md']
    for name in publish_names:shutil.copy2(ROOT/name,publication/name)
    (publication/'figures').mkdir(exist_ok=True)
    for p in (ROOT/'figures').glob('*.png'):shutil.copy2(p,publication/'figures'/p.name)
    published={p.relative_to(publication).as_posix():sha(p) for p in sorted(publication.rglob('*')) if p.is_file() and p.name not in ['release_manifest.json','SHA256SUMS.txt']}
    (publication/'release_manifest.json').write_text(json.dumps({'version':'0.2.0','sha256':published,'supplement_files':len(manifest),'reproduced_csv_files':46},indent=2))
    (publication/'SHA256SUMS.txt').write_text('\n'.join(digest+'  '+name for name,digest in published.items())+'\n')
    print(json.dumps({'archive_bytes':archive.stat().st_size,'supplement_verified_files':len(manifest),'root_upload_files':len([p for p in publication.iterdir() if p.is_file()]),'figure_files':5},indent=2))

if __name__=='__main__':main()
