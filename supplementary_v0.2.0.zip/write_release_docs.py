"""Write release documentation from verified local evidence. No network mutation."""
from pathlib import Path
import csv,json,html,re
ROOT=Path(__file__).resolve().parent
URL='https://github.com/phamnam123lite-svg/wastewater-inflow-volume-open-science'

def write(name,text):
    (ROOT/name).write_text(text.strip()+'\n',encoding='utf8')

def main():
    rep=json.loads((ROOT/'clean_reproduction/reproduction.json').read_text());assert rep['status']=='PASS'
    n=rep['files_compared'];maximum=max(x['maximum_absolute_numeric_difference'] for x in rep['tables'])
    write('README.md',f'''# Wastewater inflow forecast audit - final revision v0.2.0

**Current manuscript:** [PDF](manuscript.pdf) · [editable Markdown](manuscript.md) · [release v0.2.0]({URL}/releases/tag/v0.2.0)

Author: **Viet Nam Tran**, Faculty of Environment, Van Lang University, Ho Chi Minh City, Vietnam.

This is the final computational revision prepared for supervisor review on 10 November 2026. It is not a journal acceptance or independent external validation. All revised analyses are retrospective. The author must approve the scientific content and provide a correspondence email before submission.

## What changed

The original v0.1.0 conclusion that a simple baseline outperformed historical HGB was sensitive to the restricted loss/calendar configuration. Development-only temporal selection in v0.2.0 gives primary 12-hour MAE of **2,280.1 m³** for historical HGB, **2,221.7 m³** for flow/calendar HGB, **3,406.6 m³** for the 24-hour mean and **1,402.3 m³** for a non-operational future-rainfall oracle. The legacy configuration is retained, not erased.

Three additional temporal tests, matched loss/calendar comparisons, exact residual quantiles, maturity-aware rolling calibration, fixed-length circular bootstrap sensitivities, episode diagnostics and delayed-input/no-screening refits are included. High-volume interval reliability remains weak; the target is an approximation of integrated archived flow rates, pending confirmation of hourly aggregation semantics.

## Download the complete study

[supplementary_v0.2.0.zip](supplementary_v0.2.0.zip) contains the source observations, executable scripts, full results, five figures in PNG/SVG/PDF, editable manuscript, reference metadata, protocol, original audit and revision response. Extract it before running. The archive root is a self-contained working directory. Its `MANIFEST_SHA256.json` records every packaged file except itself.

Root-level `manuscript.pdf` and `manuscript.md` are exact copies of `manuscript_FINAL.pdf` and `manuscript_FINAL.md` inside the supplement. Root scripts match their supplementary counterparts. [release_manifest.json](release_manifest.json) records SHA-256 hashes of the published files. GitHub's automatically generated source archive contains the repository; `supplementary_v0.2.0.zip` is the complete computational study.

## Reproduce the numerical results

Use Python **3.11.9** for the closest match to the verified environment. From the extracted supplement directory:

```bash
python -m venv .venv
```

Activate it (`.venv\\Scripts\\activate` on Windows, or `source .venv/bin/activate` on macOS/Linux), then:

```bash
python -m pip install -r requirements.txt
python download_data.py
python run_analysis.py --output rerun_results
python configuration_sensitivity.py --results rerun_results
python bootstrap_diagnostic.py --output rerun_results/SYNTHETIC_bootstrap_diagnostic.csv
python verify_results.py --results rerun_results --reference results
python make_figures.py --results rerun_results --figures rerun_figures
```

`download_data.py` checks the pinned Zenodo metadata and MD5 values. It requires network access, but the verified source files are also included for an offline run; omit that command when using the bundled verified data. The analysis does not use `data/data.csv`, which is preserved solely as provider provenance.

The main analysis runs six scenarios, with 16 HGB candidates and three temporal folds for each learned information set. Runtime depends on hardware. All modelling is CPU-based; no GPU is needed. Outputs are deterministic in the tested Windows/Python environment. Other numerical libraries or platforms may differ slightly; the comparator uses relative tolerance 1e-10 and absolute tolerance 1e-8, and fails on missing, empty, changed-schema or mismatched files. Do not overwrite the reference results before comparison. Do not use `--make-reference` on your rerun.

## Render the manuscript

The text, tables and claim-to-evidence map are generated from the published reference results. PDF/HTML authoring has a separate dependency:

```bash
python -m pip install -r requirements-docs.txt
python write_manuscript.py
python build_paper.py
```

These commands regenerate `manuscript_FINAL.md`, `manuscript_FINAL.pdf` and `manuscript_FINAL.html`. They do not silently substitute a rerun's results for the versioned reference dataset. Fonts come from matplotlib; no Windows font paths or Microsoft Office installation are required. `make_figures.py` generates PNG, SVG and PDF assets.

## Executed verification

A newly created Python 3.11.9 environment installed the locked dependencies and reran the complete analysis, the matched diagnostic and the explicitly synthetic bootstrap experiment. **{n} registered CSV files reproduced; maximum absolute numerical difference = {maximum:.1f}.** See [reproduction.json](reproduction.json) and `results/verification.json` inside the supplement. Automated checks reconstructed 19,618 targets and recomputed all reported main metrics and interval arrays. Six intentionally invalid reference comparisons were rejected. This is computational reproduction by the same workflow, not independent human peer review or new-site replication.

The manuscript PDF was rendered and visually reviewed across all 15 pages; table captions remain attached to tables. `claim_evidence_map.csv` links each result group to its source tables.

## Data, licenses and limitations

Source: DHI (2025), *Inflow to a Waste Water Treatment Plant: observations and processed data*, v1, [DOI 10.5281/zenodo.15301164](https://doi.org/10.5281/zenodo.15301164). Plant data are attributed to DHI and meteorological data to DMI. Zenodo metadata records **CC BY-NC 4.0**. Derived data retain source attribution and applicable non-commercial conditions. Newly authored Python code is **MIT** licensed; this does not relicense source data or third-party articles. See `DATA_LICENSE.md`.

The dataset covers one anonymized Danish plant and lacks independent flow-aggregation/latency verification, operational forecast vintages, storage, effluent and energy outcomes. High-volume windows are overlapping and arise from few episodes. We make no Q1/Q2 acceptance claim, guaranteed coverage claim, causal treatment-benefit claim or code DOI claim. The source-data DOI is not a DOI for this study.

## Review and provenance

- [Response to all 19 audit findings](RESPONSE_TO_AUDIT_VI.md)
- [Note for the supervisor](SUPERVISOR_NOTE_VI.md)
- [Changes and remaining limitations](CHANGELOG.md)
- [Revision protocol](PROTOCOL_v0.2.0.md) and [deviations](PROTOCOL_DEVIATIONS.md)
- [Literature and novelty matrix](LITERATURE_MATRIX.md)
- [CITATION.cff](CITATION.cff)

The [v0.1.0 release]({URL}/releases/tag/v0.1.0) is retained as historical provenance. Its numerical claims and access-status notes describe the earlier version and should not be used as the current manuscript. This repository was made public by its owner before the final revision. AI assisted literature discovery, computation, verification and drafting; human author approval remains necessary.
''')
    write('DATA_LICENSE.md','''# Data and third-party rights

Source: DHI, *Inflow to a Waste Water Treatment Plant: observations and processed data*, Zenodo version 1, DOI https://doi.org/10.5281/zenodo.15301164. Source metadata records Creative Commons Attribution-NonCommercial 4.0 International: https://creativecommons.org/licenses/by-nc/4.0/ . Credit DHI and the Danish Meteorological Institute for their respective plant and weather observations.

Unmodified observations.zip and processed.zip are included with provider MD5 verification. Extracted CSVs and transformed hourly/target/prediction outputs identify their source and transformations in the methods and scripts. Preserve attribution and applicable non-commercial restrictions when reusing data. The upstream README has inconsistent BY/BY-NC prose; this release follows the more restrictive license explicitly recorded in the pinned Zenodo metadata rather than treating the data as unrestricted.

LICENSE applies only to newly authored analysis code. Third-party publications, metadata and source materials retain their own rights. No third-party full-text article is redistributed here. The dataset DOI is not a DOI for the code or manuscript.
''')
    write('PROTOCOL_DEVIATIONS.md','''# Revision chronology and deviations

The v0.2.0 protocol was written locally before the revised fits, after the original v0.1.0 results and audit stress tests were already known. It has no independent preregistration timestamp. All outcomes remain retrospective/exploratory.

The six temporal scenarios, development-only loss/annual search, three interval methods, circular block sensitivities, delay/no-QC refits and episode/phase analysis were executed. The protocol's optional mapping of episodes to rainfall storms was not implemented: a defensible hydraulic lag/event-independence interpretation is unavailable from the anonymized archive. We report threshold episodes without claiming independent storms.

The planned annual-removal sensitivity is identical to the selected primary model because development folds already excluded annual predictors. After inspecting that selection, an additional matched 2×2 loss/annual diagnostic was added, fixing seven leaves and L2=1. It is run by configuration_sensitivity.py and is explicitly post-selection, not confirmatory. The main grid, thresholds and test dates were not changed in response to its outcomes.

The explicitly synthetic AR(1) diagnostic used 200 Monte Carlo series per coefficient and 400 bootstrap replicates per series; real-data paired differences used 2,000 replicates. It tests behavior on known stationary artificial sequences only.

First-run outputs became the registered reference only after checks passed. The complete pipeline was independently re-executed computationally in a newly created environment; 34 registered CSV files matched with maximum absolute difference 0.0. It was the same code and dataset, not an independent implementation or site. Reproduction logs, environment metadata and both result sets are preserved.
''')
    write('CHANGELOG.md','''# Change log

## v0.2.0 - 10 November 2026

- Rewrote the scientific framing and conclusions after configuration sensitivity reversed the primary model ranking.
- Added development-selected loss/annual choices, three retrospective temporal origins and matched configuration/information diagnostics.
- Corrected the residual order statistic and added causally available rolling calibration.
- Replaced shortened unequal-weight blocks with fixed circular blocks and explicitly limited inferential interpretation.
- Added episode, leave-one-episode-out, nonoverlapping-phase, input-delay and no-QC sensitivities.
- Saved full grids, folds, calibration/test forecasts, interval bounds and reference results.
- Replaced the hardcoded empty-success comparator with a portable fail-closed comparator and negative tests.
- Added source-supported related work, complete author references, explicit AI disclosure, no-funding and no-conflict declarations.
- Generated portable figures, PDF/HTML manuscript, claim-to-evidence map and a 34-CSV clean-environment reproduction.
- Kept the original audit and v0.1.0 identifiable. Repository root and v0.2.0 are the current manuscript; v0.1.0 is historical.

Remaining scientific limits: one plant; no untouched external test; sparse overlapping high-volume episodes; unknown hourly aggregation/actual latency; no operational weather forecasts or treatment outcomes. Remaining submission administration: correspondence email, human author/supervisor approval, author-contribution confirmation and selected journal formatting/requirements.

## v0.1.0 - original release

Earlier restricted benchmark. Reproduction of its numerical outputs was valid, but its main model ranking was not robust to loss/calendar configuration. Do not cite the historical ranking as the conclusion of v0.2.0.
''')
    records=[
      ('A01','Major','ĐÃ SỬA','Methods 2.4; Results 3.2; configuration_sensitivity.csv','Mở grid loss/annual bằng development folds; giữ legacy và so sánh 2×2 cố định. Viết lại kết luận theo MAE 2.280,1 thay cho 7.607,1 m³.','Nghiên cứu vẫn hồi cứu; cần kiểm định dữ liệu chưa xem.'),
      ('A02','Major','ĐÃ BỔ SUNG; CÒN GIỚI HẠN','Methods 2.4; Table 2; cv_folds.csv','Thêm ba outer origin 60 ngày, calibration 45 ngày, expanding development; công bố tham số từng origin.','Không phải external validation; chưa tách được nguyên nhân mùa và vận hành.'),
      ('A03','Moderate','ĐÃ SỬA','Results 3.2-3.3; bootstrap.csv','Thêm mean24-persistence, model-mean24, oracle-mean24 và matched information sets.','Khoảng bootstrap chỉ là sensitivity; không tuyên bố ý nghĩa xác nhận.'),
      ('A04','Moderate','ĐÃ SỬA THUẬT TOÁN; NÊU GIỚI HẠN','run_analysis.py:circular_blocks; Methods 2.6','Dùng block cố định circular trong contiguous runs; kiểm tra mọi điểm có inclusion bằng nhau; AR(1) diagnostic công khai.','Wrapping tạo nối giả; stationary bootstrap assumptions không được bảo đảm ở dữ liệu thật.'),
      ('A05','Major','ĐÃ BỔ SUNG; CÒN GIỚI HẠN','Figure 5; episodes.csv; leave_one_episode_out.csv; nonoverlap.csv','Báo đủ 5 episode, kích thước, coverage; thêm leave-one-out và 12 phase không chồng target.','Không tăng số sự kiện thật; không gọi episode là bão độc lập.'),
      ('A06','Moderate','ĐÃ SỬA DIỄN GIẢI','Methods 2.5-2.6; Discussion 4.3','Phân biệt subgroup Y tương lai và wet state từ X tại issue; bỏ ý bảo đảm conditional coverage.','High-volume coverage là stress diagnostic hồi cứu.'),
      ('A07','Moderate','ĐÃ SỬA VÀ KIỂM TRA','exact_quantile; Table 3; verification.json','Dùng đúng order statistic k, infinity khi k>n, từ chối rỗng/nonfinite; tính lại mọi khoảng.','Mean24 pooled coverage hiện là 87,1296%, không còn 87,5%.'),
      ('A08','Major','ĐÃ BỔ SUNG; THU HẸP TÍNH MỚI','Introduction; References 5-6; LITERATURE_MATRIX.md','Thêm Pearson 2025, Lee & Lee 2026; nói rõ không mới ở rainfall/uncertainty/adaptive calibration.','Rà soát có mục tiêu, chưa phải systematic review đầy đủ.'),
      ('A09','Major','ĐÃ GIẢM KHẲNG ĐỊNH; CHƯA XÁC MINH NGUỒN','Methods 2.3; Results 3.5; Limitations','Đổi hourly mean khẳng định thành archived rate; volume approximation; thêm delay 1/2 giờ.','Cần DHI xác nhận sampling/averaging và timestamp/latency trước ứng dụng.'),
      ('A10','Moderate','ĐÃ BỔ SUNG','Methods 2.2; sensitivity.csv','Refit không QC; 4.656 train/2.126 cal; 2.160 test không đổi; MAE history 2.252,1 m³.','Không chứng minh missingness không gây bias hay heuristic QC đúng.'),
      ('A11','Major','ĐÃ KHẮC PHỤC TRUY CẬP','Repository/release v0.2.0; publication verification','Chủ repo đã chuyển public; cuối quy trình kiểm tra anonymous tải manuscript và supplement khớp hash.','GitHub không phải DOI archive; cần duy trì public và cân nhắc archive DOI sau duyệt.'),
      ('A12','Major','ĐÃ SỬA VÀ TÁI HIỆN','compare_reproduction.py; verify_results.py; reproduction.json','Bỏ đường dẫn máy cố định; manifest bắt buộc 34 CSV; fail rỗng/thiếu/schema/sai số; 6 negative tests.','Tolerances có khai báo; khác platform có thể cho sai số nhỏ.'),
      ('A13','Moderate','ĐÃ SỬA TUYÊN BỐ','Introduction; Methods; PROTOCOL_DEVIATIONS.md','Không gọi preregistered/prespecified confirmatory; nêu test cũ đã xem trước khi mở grid.','Không thể khôi phục tính độc lập của dữ liệu đã xem.'),
      ('A14','Moderate','ĐÃ MỞ RỘNG KIỂM TRA','verification.json; calibration_*.csv; bounds_*.csv; claim_evidence_map.csv','Lưu main cal/test và tất cả bound; kiểm tra target, split, quantile, feature future probes, rolling maturity và chỉ số.','Cùng code có thể chia sẻ sai sót khái niệm; cần human review độc lập.'),
      ('A15','Moderate','ĐÃ SỬA','build_paper.py; requirements-docs.txt; README','Font từ matplotlib; không hardcode Windows; tách reportlab; hướng dẫn chạy Python tương đối.','PDF byte-for-byte không được hứa giữa platform; số liệu đã đối chiếu.'),
      ('A16','Minor','ĐÃ SỬA TRÌNH BÀY','manuscript_FINAL.pdf; Figures 1-5; Tables 1-3','Mọi hình/bảng có gọi trong text; caption gắn bảng; kiểm tra ảnh render cả 15 trang.','Giảng viên/tạp chí có thể yêu cầu format riêng.'),
      ('A17','Minor','ĐÃ SỬA','Figure 1; Figures 2-5; Methods 2.3','Mưa ghi hourly precipitation mm; split ghi rõ; biểu đồ hạng mục dùng cột/điểm; phương trình và đơn vị thống nhất.','Đơn vị volume vẫn có điều kiện về aggregation của nguồn.'),
      ('A18','Minor','ĐÃ BỔ SUNG MỘT PHẦN','Funding; competing interests; AI disclosure; supervisor note','Theo thông tin tác giả: không funding/COI/đồng tác giả thêm; giữ đúng tên và affiliation.','Chưa có email; author contributions và phê duyệt cuối phải được người thật xác nhận.'),
      ('A19','Minor','ĐÃ SỬA','References; README; CHANGELOG','Ghi đầy đủ author list cho references; version cũ đánh dấu lịch sử; root dẫn bản mới.','Không coi GitHub release là bài đã xuất bản hay DOI nghiên cứu.')]
    with (ROOT/'audit_resolution_register.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(['ID','original_severity','status','location','correction_and_evidence','remaining_limit']);w.writerows(records)
    report='''# Đối chiếu xử lý thẩm định - bản final v0.2.0

Ngày 10/11/2026. Bảng này trả lời toàn bộ 19 phát hiện của đợt audit trước, không thay thế phản biện độc lập của giảng viên/tạp chí. Không phát hiện nào được đóng bằng cách xóa kết quả bất lợi. Trạng thái “đã sửa” nói về thay đổi có bằng chứng trong bản hiện tại; các giới hạn khoa học còn lại được giữ rõ.

Kết quả quan trọng nhất: kết luận model ranking cũ đã được thay bằng kết luận nhạy cấu hình. Kiểm tra sạch tái hiện 34 CSV với sai số tối đa 0.0. Manuscript 15 trang, Abstract 225 từ, 3 bảng, 5 hình, 9 tài liệu tham khảo có nguồn định danh. Các file nguồn của bảng/hình được nối qua claim_evidence_map.csv.
'''
    for id,sev,status,loc,fix,limit in records:
        report+=f'\n## {id} - {sev} - {status}\n\n**Vị trí:** {loc}.\n\n**Xử lý và bằng chứng:** {fix}\n\n**Giới hạn còn lại:** {limit}\n'
    report+='''
## Kết luận dành cho giảng viên

Bản hiện tại phù hợp để thảo luận khoa học dưới dạng một nghiên cứu tái phân tích/audit công khai. Những sửa chữa tính toán và trình bày đã được thực hiện, nhưng độ khái quát và tính mới phương pháp còn hạn chế. Không nên mô tả là một thuật toán mới, external validation, cải thiện xử lý nước đã thực nghiệm, hay paper chắc chắn đạt Q1/Q2. Nếu giảng viên yêu cầu bằng chứng vận hành, cần thêm dữ liệu/đối tác thay vì chỉnh câu chữ để che thiếu hụt.
'''
    write('RESPONSE_TO_AUDIT_VI.md',report)
    write('SUPERVISOR_NOTE_VI.md',f'''# Bản final gửi giảng viên - hướng dẫn đọc

Tác giả: **Viet Nam Tran**, Faculty of Environment, Van Lang University, Ho Chi Minh City, Vietnam. Phiên bản v0.2.0, ngày 10/11/2026.

## Hồ sơ nên gửi

1. manuscript_FINAL.pdf: bản thảo tiếng Anh 15 trang, 225 từ Abstract, 3 bảng và 5 hình.
2. RESPONSE_TO_AUDIT_VI.md: đối chiếu từng phát hiện và giới hạn chưa khắc phục được bằng dữ liệu hiện có.
3. supplementary_v0.2.0.zip và link GitHub {URL}/releases/tag/v0.2.0: dữ liệu nguồn, code, numerical references, figure assets và kiểm tra tái lập.

## Điểm sửa làm thay đổi nội dung khoa học

Mô hình historical HGB mới có MAE 2.280,1 m³ so với 3.406,6 của baseline 24-hour mean; cấu hình legacy là 7.607,1. Vì vậy paper không còn dùng thất bại của cấu hình legacy để suy ra giới hạn của historical information. Flow/calendar HGB tốt hơn baseline ở cả 3 temporal origins, nhưng thêm thời tiết quá khứ không cải thiện nhất quán; kết quả 24 giờ vẫn không tốt hơn baseline. Oracle tương lai chỉ để chẩn đoán.

Khoảng dự báo historical HGB có coverage 83,7% toàn tập nhưng 21,0% high-volume; rolling calibration tăng lên 88,8% và 46,9%. Chỉ có 81 cửa sổ chồng lấn trong 5 episode. Kết luận được giới hạn theo đúng số sự kiện đó.

Đã chạy lại trong Python 3.11.9 mới cài thư viện theo lock. **34 CSV trùng số học, maximum absolute difference 0.0.** Đây là reproduction bằng cùng code/data, không phải xác nhận độc lập của một nhóm nghiên cứu khác. Tất cả phân tích revision là hồi cứu vì kết quả cũ đã được xem.

## Những việc cần người thật quyết định trước khi nộp tạp chí

- Bổ sung email của corresponding author. Không tự suy đoán email.
- Tác giả và giảng viên đọc, xác nhận đóng góp tác giả, thông tin affiliation, phát biểu khoa học và việc khai báo AI. Không đưa tên giảng viên vào đồng tác giả nếu chưa có đóng góp/đồng ý phù hợp.
- Chọn tạp chí và chỉnh theo hướng dẫn riêng. Không có khẳng định đã xác minh đủ tất cả yêu cầu submission hoặc quartile hiện hành.
- Cân nhắc yêu cầu DHI giải thích hourly rate là mean hay sample, timestamp và latency; cần dữ liệu nhà máy khác/thời đoạn chưa xem nếu muốn nâng mức bằng chứng.
- Nếu cần DOI cho code/paper, archive release sau khi tác giả duyệt. DOI nguồn dữ liệu không được dùng như DOI của nghiên cứu này.

Tác giả đã trả lời không có funding/COI/đồng tác giả thêm. Các khai báo tương ứng đã đưa vào manuscript. Việc không có funding không thay cho thông tin correspondence và xác nhận author contributions.

## Định hướng tạp chí để thảo luận, không phải cam kết chấp nhận

- **Journal of Hydroinformatics:** phù hợp chủ đề dự báo, dữ liệu, uncertainty và hệ thống nước; ưu tiên cân nhắc nếu giảng viên đồng ý định vị đây là benchmark/audit. [Aims & Scope](https://iwaponline.com/jh/pages/Aims_and_Scope) đã truy xuất qua nguồn IWA ngày 10/11/2026. Đóng góp hiện tại vẫn cần bảo vệ trước phản biện về tính mới và single-site.
- **Water Science & Technology:** lĩnh vực wastewater phù hợp, nhưng paper cần liên hệ kỹ thuật vận hành đủ rõ. [Trang tạp chí](https://iwaponline.com/wst); trang hướng dẫn chi tiết trả 403 trong lần kiểm tra này.
- **Environmental Modelling & Software:** chỉ nên cân nhắc nếu mở rộng thành đánh giá phương pháp/dữ liệu nhiều site mạnh hơn. [Trang chính thức](https://www.sciencedirect.com/journal/environmental-modelling-and-software); trang scope chi tiết trả 403 trong lần kiểm tra này. Không dùng website mạo danh/nguồn trung gian để khẳng định yêu cầu tạp chí.

Phân hạng Q1/Q2 phụ thuộc năm, ngành và hệ JCR/SJR; chưa xác minh độc lập phân hạng hiện hành trong lần sửa này. Không đưa quartile chưa kiểm chứng vào cover letter. Hồ sơ chưa được gửi cho giảng viên/tạp chí bằng công cụ; chỉ được chuẩn bị và cập nhật kho công khai theo yêu cầu.
''')
    write('LITERATURE_MATRIX.md','''# Targeted prior-art and novelty matrix

Updated 10 November 2026. This is a targeted audit, not an exhaustive systematic review. Full bibliographic identities are in the manuscript and sources/. “Different” does not imply scientifically novel.

| Study / source | Verified relationship to this study | Overlap | What this analysis adds / does not claim |
|---|---|---|---|
| DHI Zenodo v1, 10.5281/zenodo.15301164; provider example | Same source dataset; provider example includes ideal future precipitation and trajectory prediction | Dataset and rainfall-aware boosted-model family | Integrated-rate target, distinct eligibility, temporal audit and released calibration bounds; no exact reproduction of the provider example or new measurement campaign |
| Sonnenschein & Ziel 2023, 10.1029/2022WR033826 | Probabilistic intraday WWTP forecasting with rain forecasts and sewer sensors | Inflow/rainfall/probabilistic prediction question | Different data and information inputs; no direct numerical ranking or claim that rainfall-aware forecasting is new |
| González Barberá et al. 2025, 10.3390/w17223225 | Rain-event wastewater inflow forecasting at Mediterranean coastal WWTPs; publisher methods/data statement inspected | ML/rain-event forecasting | Different site/target/evaluation; no cross-paper accuracy comparison |
| Pearson et al. 2025, arXiv:2506.08577v1 | Four-page sewer forecasting conference paper with diffusion and calibration; full text inspected in audit | Wet/dry and probabilistic sewer reliability | Different target and model; prevents claiming wet/dry calibration novelty |
| Lee & Lee 2026, PMLR329:1043-1045 | Publisher abstract: wastewater pH under drift, static/weighted/adaptive and rolling approaches | Drift and empirical interval adaptation | Different pH target, not same DHI observations; prevents claiming adaptation itself is new |
| Xu & Xie 2023, PMLR202:38707-38727 | Time-series residual-quantile framework (SPCI) | Dependence-aware interval motivation | This release does NOT implement SPCI and inherits no SPCI theorem |
| Bøhn, Eidnes & Jonassen 2024, arXiv:2412.14030 | Three-author record and wastewater process transfer context verified | Distribution change and model transfer | Different process/data; supporting context only |
| Roberts et al. 2017, 10.1111/ecog.02881 | Structured temporal validation methodology | Validation motivation | Does not validate this custom bootstrap or guarantee its coverage |
| Alsumaiei 2026, 10.2166/wst.2026.205 | Crossref identity and monthly influent topic verified; full text inaccessible | Related inflow modelling | Catalogue only, not used to assert full-method equivalence or support a major manuscript claim |

The restricted contribution is an executable configuration-and-information audit of a cumulative hydraulic target on open observations, with explicit retrospective status. There is no verified evidence sufficient to call it the first such study. All headline numerical comparisons are internal comparisons on common eligible windows. The review adds rather than hides close prior work.

Primary verification links: https://arxiv.org/abs/2506.08577 ; https://proceedings.mlr.press/v329/lee26a.html ; https://proceedings.mlr.press/v202/xu23r.html ; https://zenodo.org/records/15301164 . Existing Crossref/provider inspection records are retained in sources/.
''')
    write('CITATION.cff',f'''cff-version: 1.2.0
message: "Please cite the versioned research code and the separate DHI source-data DOI. This release is not a peer-reviewed publication."
type: software
title: "Configuration sensitivity and conditional reliability in wastewater inflow volume forecasting: an open-data temporal audit"
authors:
  - family-names: "Tran"
    given-names: "Viet Nam"
    affiliation: "Faculty of Environment, Van Lang University, Ho Chi Minh City, Vietnam"
version: 0.2.0
date-released: 2026-11-10
repository-code: "{URL}"
url: "{URL}/releases/tag/v0.2.0"
license: MIT
''')
    write('RELEASE_NOTES.md',f'''# Final computational revision v0.2.0

Final manuscript and reproducibility package prepared for supervisor review. Replaces the scientific interpretation in v0.1.0 while retaining the older release as provenance.

- Rewrote results/conclusions after loss/calendar sensitivity reversed the primary baseline-versus-HGB ranking.
- Added three retrospective temporal origins, matched diagnostics, maturity-aware rolling intervals, event/phase analyses and delayed-input/no-QC refits.
- Corrected residual quantile indexing and unequal bootstrap weighting; limited inferential claims.
- New Python 3.11.9 environment reproduced **{n} CSV outputs with maximum absolute numerical difference {maximum:.1f}**.
- Includes 15-page manuscript, editable text, 3 tables, 5 figures, source data, code, complete calibration/test outputs, audit response and SHA-256 manifest.

Download the current [manuscript](../../blob/main/manuscript.pdf) and [complete supplement](../../blob/main/supplementary_v0.2.0.zip). The repository file manifest records their hashes. Source data: DHI, DOI 10.5281/zenodo.15301164 (CC BY-NC 4.0); newly authored code MIT.

All revisions are retrospective. Single-site/sparse-event limitations and unknown sensor aggregation remain explicit. Correspondence email and human author/supervisor approval remain required before journal submission. No paper acceptance, independent external validation or code DOI is claimed.
''')
    from finalize_external_docs import update
    update(ROOT)
    # Lightweight UTF-8 HTML companions for the Vietnamese review notes.
    for name in ['SUPERVISOR_NOTE_VI','RESPONSE_TO_AUDIT_VI']:
        raw=(ROOT/(name+'.md')).read_text(encoding='utf8');parts=[]
        for para in raw.split('\n\n'):
            if para.startswith('#'):
                count=len(para)-len(para.lstrip('#'));parts.append(f'<h{count}>'+html.escape(para[count:].strip())+f'</h{count}>')
            else:
                p=html.escape(para);p=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',p);p=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',p)
                parts.append('<p>'+p.replace('\n','<br>')+'</p>')
        (ROOT/(name+'.html')).write_text('<!doctype html><html lang="vi"><meta charset="utf-8"><style>body{max-width:980px;margin:40px auto;padding:0 24px;font:17px/1.6 Arial;color:#183340}h2{border-top:1px solid #ccd9df;padding-top:18px}a{color:#176b87}</style><body>'+'\n'.join(parts)+'</body></html>',encoding='utf8')

if __name__=='__main__':main()
