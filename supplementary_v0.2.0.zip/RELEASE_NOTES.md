# Final computational revision v0.2.0

Final manuscript and reproducibility package prepared for supervisor review. Replaces the scientific interpretation in v0.1.0 while retaining the older release as provenance.

- Rewrote results/conclusions after loss/calendar sensitivity reversed the primary baseline-versus-HGB ranking.
- Added three retrospective temporal origins, matched diagnostics, maturity-aware rolling intervals, event/phase analyses and delayed-input/no-QC refits.
- Corrected residual quantile indexing and unequal bootstrap weighting; limited inferential claims.
- New Python 3.11.9 environment reproduced **34 CSV outputs with maximum absolute numerical difference 0.0**.
- Includes 16-page manuscript, editable text, 4 tables, 5 figures, source data, code, complete calibration/test outputs, audit response and SHA-256 manifest.

Download the current [manuscript](../../blob/main/manuscript.pdf) and [complete supplement](../../blob/main/supplementary_v0.2.0.zip). The repository file manifest records their hashes. Source data: DHI, DOI 10.5281/zenodo.15301164 (CC BY-NC 4.0); newly authored code MIT.

All revisions are retrospective. Two-site/generalization limitations and unknown sensor aggregation remain explicit. Correspondence email and human author/supervisor approval remain required before journal submission. No paper acceptance, zero-shot transfer or prospective operational validation or code DOI is claimed.

External extension: Köln-Weiden, Germany, 6,588 test windows, 41 high-volume episodes, 12 additional exactly reproduced CSVs (46 total). Source CC BY 4.0; see manuscript Section 3.6/Table 4.
