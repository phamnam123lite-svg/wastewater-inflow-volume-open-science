"""Synchronize all release notes with the completed, independently sourced site extension."""
from pathlib import Path
import json,pandas as pd

def update(root):
    rep=json.loads((root/'external_clean/reproduction.json').read_text());assert rep['status']=='PASS'
    assert rep['files_compared']==12
    for name in ['README.md','SUPERVISOR_NOTE_VI.md','RESPONSE_TO_AUDIT_VI.md','CHANGELOG.md','RELEASE_NOTES.md','CITATION.cff']:
        p=root/name;s=p.read_text(encoding='utf8')
        s=s.replace('15 pages','16 pages').replace('15-page','16-page').replace('15 trang','16 trang').replace('225 từ','218 từ')
        s=s.replace('3 bảng và 5 hình','4 bảng và 5 hình').replace('3 bảng, 5 hình, 9 tài liệu','4 bảng, 5 hình, 10 tài liệu').replace('3 tables, 5 figures','4 tables, 5 figures')
        s=s.replace('an open-data temporal audit','a two-site open-data audit')
        p.write_text(s,encoding='utf8')
    p=root/'README.md';s=p.read_text(encoding='utf8')
    s=s.replace('It is not a journal acceptance or independent external validation.','It is not a journal acceptance. It includes an independently sourced German-site evaluation with local refitting, not zero-shot model transfer or a prospective operational trial.')
    s=s.replace('The dataset covers one anonymized Danish plant and lacks independent flow-aggregation/latency verification, operational forecast vintages, storage, effluent and energy outcomes. High-volume windows are overlapping and arise from few episodes.',
      'The Danish source covers one anonymized plant; a second source covers Köln-Weiden, Germany, in 2017-2019. There are five Danish and 41 German high-volume threshold episodes. The study still lacks independently confirmed sensor aggregation/actual latency and operational control/effluent/energy endpoints. Both sites use overlapping issue windows; models are refitted locally.')
    s=s.replace('not independent human peer review or new-site replication.','not independent human peer review. The external extension is a separate-site methodological replication with locally refitted models.')
    s=s.replace('Derived data retain source attribution and applicable non-commercial conditions. Newly authored Python code',
      'Danish derived data retain source attribution and applicable non-commercial conditions. German observations are separately licensed CC BY 4.0 by Sonnenschein and Ziel, DOI [10.5281/zenodo.6992694](https://doi.org/10.5281/zenodo.6992694). Newly authored Python code')
    s=s.replace('## Render the manuscript','''## External-site extension

The final paper additionally evaluates **6,588 German test windows** and **700 high-volume windows in 41 threshold episodes**. Flow/rain HGB MAE was **1,661.9 m³** versus **3,293.1 m³** for the 24-hour mean. Historical rain improved accuracy in Germany, while rolling calibration deteriorated there. These findings prevent universal claims based on the Danish site alone. All **12 external CSV tables** reproduced exactly, so the two numerical comparisons cover **46 CSV tables in total**, each with maximum absolute difference 0.0.

From the complete extracted supplement:

```bash
python external_site.py --output external_rerun --download
python verify_external.py --results external_rerun --reference external_results
```

Omit `--download` for offline use of the bundled checksum-verified German source. The source uses L/s and mm/min at quarter-hour resolution; aggregation is right-closed and causal. Its uniform archive clock is not asserted to be UTC. See `EXTERNAL_SITE_PROTOCOL.md`, `external_results/external_source_audit.json`, and `LIMITATIONS_RESOLVED_VI.md`.

## Render the manuscript''')
    s=s.replace('A newly created Python 3.11.9 environment','A newly created Python 3.11.9 environment')
    p.write_text(s,encoding='utf8')
    p=root/'SUPERVISOR_NOTE_VI.md';s=p.read_text(encoding='utf8')
    s=s.replace('không phải xác nhận độc lập của một nhóm nghiên cứu khác.','không phải xác nhận độc lập của một nhóm nghiên cứu khác. Ngoài 34 CSV chính, đã chạy lại 12 CSV kiểm định nhà máy Đức, cũng khớp tuyệt đối; tổng cộng 46 bảng. Kiểm định Đức là refit tại site thứ hai, không phải zero-shot transfer.')
    s=s.replace('cần dữ liệu nhà máy khác/thời đoạn chưa xem nếu muốn nâng mức bằng chứng.','đã bổ sung site Đức, nhưng vẫn cần thêm nhà máy và một thử nghiệm vận hành tương lai nếu muốn nâng mức bằng chứng.')
    s=s.replace('tính mới và single-site.','tính mới và khả năng khái quát từ hai site.')
    s=s.replace('nếu mở rộng thành đánh giá phương pháp/dữ liệu nhiều site mạnh hơn.','nếu tiếp tục mở rộng từ hai site hiện có thành đánh giá phương pháp và ứng dụng vận hành mạnh hơn.')
    s+='''
## Giới hạn khoa học đã được xử lý thêm theo yêu cầu

Đã bổ sung dữ liệu độc lập về nguồn và địa điểm: Köln-Weiden, Đức, DOI 10.5281/zenodo.6992694, CC BY 4.0. Có 17.484 train, 2.124 calibration và 6.588 test; high-volume gồm 700 cửa sổ/41 episode. Kiểm tra trực tiếp 8.712 target từ 48 mẫu 15 phút, dùng hệ số đổi đơn vị 900/1000. Không khẳng định múi giờ chưa được nguồn xác nhận.

Kết quả mới không chỉ củng cố paper mà còn buộc thu hẹp kết luận: mưa quá khứ có ích tại Đức; annual predictors không gây suy giảm mạnh giống Đan Mạch; rolling calibration giảm coverage tại Đức. Paper final đã phản ánh đầy đủ các khác biệt này. Chi tiết và trạng thái từng giới hạn nằm trong LIMITATIONS_RESOLVED_VI.md.
''';p.write_text(s,encoding='utf8')
    p=root/'CHANGELOG.md';s=p.read_text(encoding='utf8').replace('Remaining scientific limits: one plant; no untouched external test; sparse overlapping high-volume episodes;',
      'Added external-site replication on Köln-Weiden (2017-2019), 12 additional exactly reproduced CSVs, 41 threshold episodes, and site-dependent rainfall/calibration findings.\n\nRemaining scientific limits: two plants, no prospective operational trial, overlapping high-volume episodes;')
    p.write_text(s,encoding='utf8')
    p=root/'RELEASE_NOTES.md';s=p.read_text(encoding='utf8').replace('Single-site/sparse-event limitations','Two-site/generalization limitations').replace('independent external validation','zero-shot transfer or prospective operational validation')
    s+='\nExternal extension: Köln-Weiden, Germany, 6,588 test windows, 41 high-volume episodes, 12 additional exactly reproduced CSVs (46 total). Source CC BY 4.0; see manuscript Section 3.6/Table 4.\n';p.write_text(s,encoding='utf8')
    p=root/'PROTOCOL_DEVIATIONS.md';s=p.read_text(encoding='utf8')
    s+='''
## External extension after the author requested additional limit mitigation

EXTERNAL_SITE_PROTOCOL.md was recorded before loading the German measurement CSV and before computing its errors, after the Danish revision was complete. The observed source has a naive uniform clock; we retained it rather than asserting UTC. Right-closed hourly aggregation of four quarter-hour samples prevents future measurement use. The separately downloaded radar forecast was not modelled because the numbered columns and operational 12-hour availability could not be verified. Existing sewer-level columns were not added to the matched flow/rain comparison. All planned 12-hour external models and residual-calibration comparisons were executed and saved.

Twelve external CSVs were reproduced in the clean environment with zero maximum numeric difference. The supplementary package contains the reference CSVs and both reproduction reports; duplicate identical rerun CSVs are retained locally in D:\\P2\\v0.2.0 and omitted from the portable archive to avoid unnecessary duplication.
''';p.write_text(s,encoding='utf8')
    p=root/'DATA_LICENSE.md';s=p.read_text(encoding='utf8')
    s+='''
## Independently licensed German source

Sonnenschein, Björn, and Ziel, Florian (2022). Wastewater Treatment Plant Inflow Rate, Network Water Levels and Rain Rate for Koeln Weiden, Germany, v1.0. DOI https://doi.org/10.5281/zenodo.6992694 . License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Attribution must identify the source and our right-closed hourly aggregation, unit conversion and forecasting transformations. The Danish CC BY-NC restriction does not relicense this independent German source. Both sources' distinct conditions must be respected when using the combined research package.

The related radar-forecast archive DOI 10.5281/zenodo.6992869 (CC BY 4.0) was downloaded and checksum-inspected for suitability, but is not a model input. Its metadata and exclusion reason are retained; the portable archive does not need to redistribute that unused CSV.
''';p.write_text(s,encoding='utf8')
    p=root/'LITERATURE_MATRIX.md';s=p.read_text(encoding='utf8')
    s+='''
## Added external source and an additional close comparator

Sonnenschein and Ziel's German observations, DOI 10.5281/zenodo.6992694, are now used as an external-site methodological replication. This is the same dataset used in their prior intraday study; our integrated 12-hour target, temporal split, HGB configuration audit and residual-calibration comparison differ. Dataset reuse is explicit and is not called new data or exact reproduction of their published method. Their radar forecast record is 6992869; a malformed DOI in a publisher-rendered availability sentence was not copied as a verified identifier.

Mateos-Bravo et al. (2026), Data Quality over Model Complexity: A Leakage-Aware, Horizon-Aware Forecasting Pipeline for Degraded Sensor Streams in a Small-Population Wastewater Treatment Plant, Zenodo 10.5281/zenodo.20596898 v2, was also inspected. Its public record explicitly contains derived figures/metrics/prediction arrays, not raw measurements or source code. It is relevant to the non-novelty of leakage-aware wastewater forecasting but cannot supply raw inflow/rain data for this evaluation. It is catalogued here rather than treated as a full-text peer-reviewed methodological comparison.

The Mediterranean coastal WWTP paper (10.3390/w17223225) explicitly makes raw utility data available only on reasonable request subject to permission/data-use agreement. That prevents immediate open reproduction and is why it was not selected as the additional site. No request was sent to its authors.
''';p.write_text(s,encoding='utf8')
    p=root/'audit_resolution_register.csv';df=pd.read_csv(p)
    updates={
      'A02':('ĐÃ BỔ SUNG TEMPORAL VÀ EXTERNAL SITE','Methods 2.4, 2.7; Tables 2, 4; external_results/','Thêm 3 Danish origins và site Đức (17.484 train/2.124 cal/6.588 test). Refit tại site thứ hai; 12 CSV tái lập đúng.','Chưa có prospective trial; không phải zero-shot transfer.'),
      'A05':('ĐÃ MỞ RỘNG BẰNG CHỨNG SỰ KIỆN','Figure 5; Section 3.6; external_episodes.csv','Giữ 5 Danish episodes và thêm 41 German episodes/700 cửa sổ high; báo sự khác biệt coverage giữa site.','Các episode vẫn có thể phụ thuộc; không phải 700 sự kiện độc lập.'),
      'A09':('ĐÃ KIỂM TRA ĐƠN VỊ VÀ NHÂN QUẢ; CÒN METADATA','Methods 2.3, 2.7; verify_external.py','Danish target được gọi approximation, có delay sensitivity. German CSV ghi L/s và mm/min; 8.712 target kiểm tra trực tiếp từ 48 mẫu quarter-hour.','Chưa xác nhận DHI averaging/latency; German timezone không suy đoán.'),
      'A14':('ĐÃ MỞ RỘNG VÀ TÁI HIỆN HAI SITE','verification.json; external_verification.json; claim_evidence_map.csv','34 CSV chính + 12 CSV external tái lập với chênh lệch tối đa 0.0; kiểm tra metric, interval, target, causality.','Cùng code/workflow, chưa phải independent human review.')}
    for key,(status,loc,fix,remaining) in updates.items():
        mask=df.ID==key;df.loc[mask,['status','location','correction_and_evidence','remaining_limit']]=[status,loc,fix,remaining]
    df.to_csv(p,index=False)
    report='''# Đối chiếu xử lý toàn bộ 19 phát hiện - final v0.2.0

Đã sửa và bổ sung nghiên cứu trên hai nguồn/địa điểm: Đan Mạch và Köln-Weiden, Đức. Bản thảo final 16 trang, Abstract 218 từ, 4 bảng, 5 hình, 10 references chính. Chạy lại 34 CSV chính và 12 CSV external, tất cả sai số số học tối đa 0.0. Đây là computational reproduction, không phải phản biện độc lập của con người.

Các trạng thái dưới đây phân biệt thay đổi đã kiểm chứng với giới hạn chưa có nguồn xác nhận. Xem thêm LIMITATIONS_RESOLVED_VI.md.
'''
    for _,row in df.iterrows():
        report+=f"\n## {row.ID} - {row.original_severity} - {row.status}\n\n**Vị trí:** {row.location}.\n\n**Xử lý và bằng chứng:** {row.correction_and_evidence}\n\n**Giới hạn còn lại:** {row.remaining_limit}\n"
    (root/'RESPONSE_TO_AUDIT_VI.md').write_text(report,encoding='utf8')
    (root/'LIMITATIONS_RESOLVED_VI.md').write_text('''# Giới hạn khoa học: đã xử lý đến đâu?

Ngày 10/11/2026. Không thể biến thiếu bằng chứng thành bằng chứng bằng cách sửa câu chữ. Bản final xử lý các giới hạn bằng phân tích mới hoặc thu hẹp phát biểu có căn cứ.

| Giới hạn | Hành động đã thực hiện | Trạng thái sau sửa |
|---|---|---|
| Một nhà máy | Thêm Köln-Weiden, Đức, DOI 10.5281/zenodo.6992694; mô hình refit trên 2017-2018, calibration quý 1/2019, test phần còn lại 2019 | ĐÃ GIẢM: hai site; chưa đại diện mọi công nghệ/catchment |
| Chỉ 5 episode high-volume | Thêm 700 cửa sổ trong 41 episode tại Đức; không gộp thành sự kiện độc lập | ĐÃ GIẢM: nhiều episode hơn; vẫn có phụ thuộc |
| Kết luận model ranking do loss/calendar | Grid trong development, matched 2×2, 3 origins; thử ở site thứ hai | ĐÃ SỬA: annual feature bất lợi mạnh tại Danish không lặp lại tại German; không đưa quy tắc phổ quát |
| Mưa quá khứ “không hữu ích” | Matched information tests hai site | ĐÃ SỬA: mưa có ích rõ ở German, không nhất quán ở Danish; kết luận phụ thuộc site |
| Adaptive intervals luôn tốt hơn | So pooled/wet-dry/rolling theo maturity ở cả hai site | ĐÃ BÁC BỎ TỔNG QUÁT HÓA: rolling cải thiện Danish nhưng giảm German coverage |
| Đơn vị, target, giờ tổng hợp | German header L/s, mm/min; quy đổi và tích phân trực tiếp 48 mẫu; right-closed aggregation; không gắn UTC khi chưa biết | ĐÃ KIỂM TRA tính toán; semantics cảm biến và timezone vật lý còn CHƯA XÁC MINH |
| Latency lịch sử | Refit delay 1/2 giờ tại primary Danish | ĐÃ ĐỊNH LƯỢNG độ nhạy; actual telemetry latency chưa biết |
| Dữ liệu thiếu/QC | Không nội suy target; complete windows; no-QC refit; báo counts; German chỉ loại nonfinite/negative | ĐÃ ĐÁNH GIÁ; không chứng minh missing-at-random |
| Bootstrap và calibration rank | Sửa rank, edge cases; fixed circular blocks uniform inclusion; dependence sensitivity và synthetic diagnostic | ĐÃ SỬA code; tính stationarity/coverage thực vẫn không bảo đảm |
| Khả năng tái lập | Môi trường sạch; 34+12 CSV khớp; 2 bộ reference; full predictions và audit logs | ĐÃ XÁC MINH reproduction; không thay thế independent human review |
| Forecast mưa thực 12h | Kiểm tra archive 6992869 và checksum; chỉ có numbered columns chưa xác minh horizon/issue semantics phù hợp | CHƯA ĐỦ BẰNG CHỨNG; không tráo future observations thành operational forecasts |
| Hiệu quả xử lý, storage, energy | Bỏ mọi suy luận forecast error=storage saving; xác định cần geometry, controls, initial state, constraints, effluent/energy endpoints | CHƯA THỂ KIỂM ĐỊNH bằng nguồn hiện có; không phải kết quả paper |
| Tính mới | Bổ sung prior art gần; công khai reuse datasets và targeted review | Đóng góp là audit hai site có tái lập, không phải thuật toán mới hay “đầu tiên” |

Các phần không giải quyết được bằng dữ liệu hiện có cần nhà cung cấp xác nhận hoặc chiến dịch đánh giá mới. Không gửi liên hệ, cam kết hợp tác hoặc hồ sơ tạp chí thay tác giả. Trước khi nộp: email correspondence, xác nhận đóng góp tác giả, phê duyệt khoa học của tác giả/giảng viên, và kiểm tra yêu cầu của tạp chí đã chọn.
''',encoding='utf8')
