# Đề cương nghiên cứu

## Tên làm việc

Information availability and conditional reliability in 12-hour wastewater inflow-volume forecasting: a reproducible single-plant audit.

## Vấn đề và research gap

Thông tin tổng thể tích nước vào một cửa sổ vận hành có ích cho dự phòng thủy lực, nhưng sai số trung bình không thể hiện đầy đủ rủi ro khi thể tích cao. Ví dụ DHI có giả định perfect precipitation; các công trình trước đã nghiên cứu probabilistic inflow forecasting. Câu hỏi còn cần kiểm tra trên bộ mở này là khi bỏ thông tin tương lai và bắt đầu từ quan trắc chưa nội suy, mô hình và khoảng dự báo có còn hữu ích ở giai đoạn kiểm định theo thời gian hay không. Đây là gap ứng dụng hẹp được đề xuất, không phải khẳng định chưa tồn tại phương pháp.

## Mục tiêu và câu hỏi

1. Xây dựng benchmark thể tích tích lũy không sử dụng thông tin hậu nghiệm trong mô hình vận hành.
2. Định lượng đóng góp của weather history so với flow history, và đối chứng perfect future rain.
3. Đo độ phủ khoảng dự báo và underprediction ở wet/high-volume windows.
4. Làm rõ các điều kiện dữ liệu bổ sung cần có trước khi dùng dự báo cho quyết định thủy lực.

RQ1: Past meteorology có giảm MAE ngoài thời gian huấn luyện không? RQ2: Cùng lớp mô hình, perfect future rain thay đổi sai số bao nhiêu? RQ3: Độ phủ toàn tập có che khuất độ phủ kém ở high-volume windows không? RQ4 (thăm dò): kết luận thay đổi ở horizon 6 và 24 giờ hoặc wet/dry calibration không?

## Giả thuyết

H1: MAE(HGB history) < MAE(HGB flow/calendar). H2: MAE(HGB oracle) < MAE(HGB history). H3: độ phủ pooled interval trên high-volume subset thấp hơn toàn tập. H1/H2 dùng CI bootstrap cho chênh lệch paired absolute error. H3 báo cáo mô tả, không dùng binomial test giả định các cửa sổ độc lập. Chấp nhận kết quả bác bỏ kỳ vọng; không sửa giả thuyết sau khi xem test.

## Đóng góp dự kiến

Một audit có thể chạy lại của giới hạn thông tin đầu vào, quy trình không nội suy target, khoảng dự báo có calibration riêng và phân tích lỗi theo trạng thái tải. Giá trị kỹ thuật là thể hiện độ tin cậy đầu vào cho chuẩn bị vận hành, không phải chỉ xếp hạng ML. Không xây thuật toán mới, không chứng minh giảm điện, tăng removal hoặc giảm overflow.

## Khung khái niệm

Mưa và trạng thái mạng thu gom → inflow quá khứ/hiện tại → thông tin sẵn có tại t → dự báo tổng V(t,h) → bất định và underprediction → yêu cầu dữ liệu cho hydraulic planning. Nhánh oracle đưa mưa t+1…t+h vào riêng để chẩn đoán giá trị thông tin. Liên kết cuối tới storage/overflow cần dữ liệu capacity và điều khiển, chưa được đo trong nghiên cứu.

## Phương pháp và workflow

Nguồn cố định: DHI/Zenodo v1 DOI 10.5281/zenodo.15301164. Tải, đối chiếu MD5, lưu SHA-256. Chuẩn hóa UTC, xử lý missing/flags, dựng biến theo quá khứ. V(t,h)=ΣQ(t+k)×1h, k=1…h; primary h=12, secondary h=6/24. Bắt đầu dự báo khi giá trị giờ t đã sẵn có; đây là giả định latency cần xác minh với đơn vị vận hành.

Tách 60% timeline đầu làm development, 20% tiếp calibration, 20% cuối test. Purge label windows trước mỗi biên. Ba inner expanding folds, gap h; median imputation và scaling chỉ fit trong fold. Baseline persistence, mean24, seasonal24; ridge; HGB flow; HGB history; HGB oracle. Hyperparameter grid nhỏ cố định ở PROTOCOL.md. Không chọn winner bằng test rồi gọi đó là kiểm định độc lập.

## Phân tích thống kê

Đơn vị phân tích là forecast window, không phải thí nghiệm độc lập. MAE chính; RMSE, R², bias, positive underprediction phụ. Không dùng MAPE làm chính vì denominator nhỏ tạo bất ổn. High volume định nghĩa từ phân vị 90% target training; wet từ tổng mưa sáu giờ đến t >0. Tính residual intervals mức danh nghĩa 90% từ calibration; so pooled và wet/dry. Không tuyên bố bảo đảm conformal distribution-free vì chuỗi không exchangeable.

Bootstrap paired loss: 2.000 mẫu, block tối đa 48 giờ primary; 24 và 168 sensitivity, không vượt gaps của chuỗi issue-time hợp lệ. CI là gần đúng và không loại bỏ nonstationarity. Spearman descriptive correlations; residual autocorrelation và quan hệ absolute residual–prediction để đánh giá dependence/heteroscedasticity. Group-shift feature sensitivity giữ nhóm flow/weather/calendar, không coi là causal effect. Không diễn giải p-value i.i.d. như bằng chứng kiểm định hợp lệ của chuỗi thời gian.

## Validation và giới hạn

Kiểm định cuối là holdout theo thời gian cùng nhà máy, **không phải external independent plant**. Temporal folds huấn luyện và horizon sensitivity hỗ trợ robustness nhưng không thay thế xác nhận ngoài địa điểm. Thiếu nhiều năm/mùa, missingness không ngẫu nhiên, địa điểm ẩn, thiếu vận hành/effluent/inflow concentrations, uncertain latency, đơn vị/hourly aggregation. Rolling aggregate overlap gây autocorrelation mạnh; số hàng không bằng effective sample size. Oracle là future observed rain, không phải chất lượng weather forecast thực tế, cũng không phải mathematical performance upper bound.

## Nghiên cứu tiếp theo cần thiết

Ưu tiên ít nhất một nhà máy độc lập và nhiều mùa; thu thập forecast weather có issue timestamps, sensor latency và fault logs, hydraulic/biological capacity, tank levels, outflow/control logs, chất lượng đầu vào/đầu ra và năng lượng. Sau đó kiểm tra adaptation/conformal time-series phù hợp, hiệu chỉnh mùa và closed-loop simulation đã hiệu chuẩn. Chỉ khi có dữ liệu này mới lượng hóa tác động tới overflow, treatment stability và energy.
