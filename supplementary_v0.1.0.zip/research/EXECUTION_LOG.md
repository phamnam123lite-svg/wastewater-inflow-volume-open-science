# Execution and provenance log

- Research date: 2026-11-09 (user time zone Asia/Bangkok). Observation timestamps in outputs are explicitly UTC.
- Python and NumPy/pandas/SciPy/scikit-learn/Matplotlib were available locally. Initial direct downloads failed in the restricted network; network permission was granted and subsequent requests succeeded.
- Broad web discovery was followed by Crossref/OpenAlex queries and DOI metadata verification. Google Scholar and Semantic Scholar access probes returned HTTP 429. Initial Crossref rate limits on three DOI lookups were resolved in separate retries; both initial limitations and retry logs are retained. Seventeen article DOIs were verified, supplemented by Zenodo, arXiv and PMLR primary records.
- Candidate datasets were screened. DHI was selected for raw availability, license metadata, temporal information and a tractable hydraulic prediction question. Other datasets were not represented as fully audited.
- Downloaded observations.zip and processed.zip matched Zenodo MD5. Actual modelling uses the original observations, not the interpolated processed.csv.
- Source DHI notebooks were inspected at repository commit 68cc22b5de3bbbc09c0bf63c6d5a9ef376d5fd6c. Their perfect-future-rain assumption and linear interpolation are explicitly documented; no hidden-leakage allegation is made.
- PROTOCOL.md was written before model fitting. Model configurations and horizons were not revised in response to test performance. Negative findings were retained.
- Full pipeline fitted and evaluated four learned configurations and three baselines at each of 12, 6 and 24 hours. Hyperparameter optimization used training-only temporal folds.
- During QA, pandas datetime resolution exposed an error in bootstrap gap detection. The code was corrected to normalize to nanoseconds; uncertainty was recomputed, and the full pipeline was rerun. Only corrected intervals are in reports. Predictions were unchanged by this correction. Contiguous-run audit is saved separately.
- Independent verification re-summed targets by timestamps, recalculated saved MAE/RMSE, checked partition separation, and perturbed future observations to confirm historical feature causality.
- Five figures were exported to PNG, SVG and PDF and visually inspected. The English manuscript has a 228-word abstract.
- No external messages, journal submissions, public code publication or fabricated experiments were performed. No external plant validation, real forecast replay, process-control simulation, treatment-efficiency experiment or energy-benefit calculation is claimed.
