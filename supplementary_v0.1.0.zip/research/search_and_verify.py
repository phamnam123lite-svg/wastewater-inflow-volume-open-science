"""Retrieve metadata only; an API hit is not a full-text literature assessment."""
from pathlib import Path
import requests,json,time,concurrent.futures
P=Path(__file__).resolve().parent/'sources';P.mkdir(exist_ok=True)
DOIS=['10.1029/2022WR033826','10.3390/w17223225','10.1111/ecog.02881','10.1016/j.cej.2023.143073','10.1016/j.jece.2025.116812','10.1016/j.envpol.2025.127220','10.1016/j.scitotenv.2024.173999','10.1111/wej.12945','10.1021/acsestwater.4c01047','10.3389/fenvs.2026.1941653','10.1016/j.cej.2026.178098','10.1016/j.dwt.2025.101338','10.1016/j.jconhyd.2024.104426','10.1016/j.jhazmat.2024.133442','10.1016/j.chemosphere.2024.144031','10.1039/D4EW00924J','10.2166/wst.2026.205']
def getdoi(doi):
    u='https://api.crossref.org/works/'+doi
    try:
        r=requests.get(u,timeout=30);r.raise_for_status();m=r.json()['message']
        return {'doi':doi,'status':r.status_code,'title':m.get('title'),'authors':m.get('author'),'published':m.get('published'),'journal':m.get('container-title'),'url':m.get('URL'),'raw':m}
    except Exception as e:return {'doi':doi,'error':str(e)}
refs=list(concurrent.futures.ThreadPoolExecutor(max_workers=4).map(getdoi,DOIS))
(P/'verified_crossref.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf8')
queries=['wastewater inflow forecast cumulative volume uncertainty rainfall','WaterBench TimeSeries WWTPINflow','wastewater treatment machine learning data leakage temporal validation']
logs=[]
for q in queries:
    calls=[('Crossref','https://api.crossref.org/works',{'query':q,'rows':10,'filter':'from-pub-date:2021-01-01,until-pub-date:2026-11-09'}),('OpenAlex','https://api.openalex.org/works',{'search':q,'per-page':10,'filter':'from_publication_date:2021-01-01,to_publication_date:2026-11-09'}),('Semantic Scholar','https://api.semanticscholar.org/graph/v1/paper/search',{'query':q,'limit':10,'fields':'title,authors,year,externalIds,url'})]
    for provider,u,params in calls:
        try:
            r=requests.get(u,params=params,timeout=30);logs.append({'provider':provider,'query':q,'url':r.url,'status':r.status_code,'response':r.json()})
        except Exception as e:logs.append({'provider':provider,'query':q,'error':str(e)})
    print(q,flush=True)
try:
    r=requests.get('https://scholar.google.com/scholar',params={'q':queries[0]},timeout=20)
    logs.append({'provider':'Google Scholar','query':queries[0],'status':r.status_code,'url':r.url,'note':'Access probe only; no results treated as verified.'})
except Exception as e:logs.append({'provider':'Google Scholar','error':str(e)})
(P/'academic_search_log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2),encoding='utf8')
print('Verified',sum('title' in r for r in refs),'DOIs',flush=True)
