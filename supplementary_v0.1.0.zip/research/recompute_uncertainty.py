"""Recompute block intervals from unchanged saved predictions; no model refitting."""
from pathlib import Path
import numpy as np,pandas as pd,json
from run_analysis import block_ci
R=Path(__file__).resolve().parent/'results';rows=[];audit=[]
for h in [12,6,24]:
    p=pd.read_csv(R/f'predictions_{h}h.csv',index_col=0,parse_dates=True)
    ns=p.index.as_unit('ns').asi8
    cuts=np.r_[0,np.flatnonzero(np.diff(ns)!=3600*10**9)+1,len(p)]
    runs=np.diff(cuts)
    audit.append({'horizon':h,'contiguous_runs':len(runs),'min_run':int(runs.min()),'max_run':int(runs.max()),'median_run':float(np.median(runs))})
    for a,b in [('hgb_history','hgb_flow'),('hgb_oracle','hgb_history'),('hgb_history','persistence'),('ridge_history','persistence')]:
        delta=np.abs(p[a]-p.observed)-np.abs(p[b]-p.observed)
        for block in [24,48,168]:
            mean,lo,hi=block_ci(delta,p.index,block)
            rows.append({'horizon':h,'comparison':a+' minus '+b,'block_hours':block,'MAE_difference':mean,'CI_low':lo,'CI_high':hi})
    print(h,'complete',flush=True)
pd.DataFrame(rows).to_csv(R/'bootstrap_comparisons.csv',index=False)
(R/'bootstrap_run_audit.json').write_text(json.dumps(audit,indent=2))
