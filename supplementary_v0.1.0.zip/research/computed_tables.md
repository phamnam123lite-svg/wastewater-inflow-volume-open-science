# Computed tables

All flow-volume errors are in m³. These tables are generated directly from CSV outputs.


## Primary 12-hour point scores

| horizon | model | group | n | MAE_m3 | RMSE_m3 | R2 | bias_m3 | mean_underprediction_m3 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 12 | persistence | all | 2160 | 3740.217 | 6185.426 | 0.219 | 168.45 | 1785.884 |
| 12 | mean24 | all | 2160 | 3406.606 | 6128.244 | 0.233 | 229.599 | 1588.503 |
| 12 | seasonal24 | all | 2160 | 4056.767 | 7787.931 | -0.239 | 217.731 | 1919.518 |
| 12 | ridge_history | all | 2160 | 4655.342 | 5743.779 | 0.326 | 3250.687 | 702.327 |
| 12 | hgb_flow | all | 2160 | 7543.694 | 8452.498 | -0.459 | 6525.911 | 508.891 |
| 12 | hgb_history | all | 2160 | 7607.104 | 8633.008 | -0.522 | 6811.403 | 397.851 |
| 12 | hgb_oracle | all | 2160 | 2044.108 | 2756.369 | 0.845 | 1505.881 | 269.113 |


## 12-hour pooled coverage

| horizon | model | method | group | n | coverage | width_m3 | interval_score_m3 | upper_exceedance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 12 | persistence | pooled | all | 2160 | 0.895 | 15053.949 | 30332.646 | 0.053 |
| 12 | persistence | pooled | wet | 707 | 0.779 | 15066.051 | 49417.556 | 0.066 |
| 12 | persistence | pooled | dry | 1453 | 0.952 | 15048.06 | 21046.32 | 0.047 |
| 12 | persistence | pooled | high | 81 | 0.346 | 15093.346 | 206308.542 | 0.407 |
| 12 | mean24 | pooled | all | 2160 | 0.875 | 14045.587 | 32418.413 | 0.064 |
| 12 | mean24 | pooled | wet | 707 | 0.793 | 14045.587 | 49393.967 | 0.122 |
| 12 | mean24 | pooled | dry | 1453 | 0.915 | 14045.587 | 24158.456 | 0.036 |
| 12 | mean24 | pooled | high | 81 | 0.235 | 14045.587 | 260591.795 | 0.543 |
| 12 | seasonal24 | pooled | all | 2160 | 0.859 | 15915.613 | 41767.964 | 0.075 |
| 12 | seasonal24 | pooled | wet | 707 | 0.791 | 15914.495 | 62069.759 | 0.161 |
| 12 | seasonal24 | pooled | dry | 1453 | 0.892 | 15916.158 | 31889.527 | 0.032 |
| 12 | seasonal24 | pooled | high | 81 | 0.222 | 15916.245 | 352979.489 | 0.63 |
| 12 | ridge_history | pooled | all | 2160 | 0.882 | 15056.726 | 22800.961 | 0.029 |
| 12 | ridge_history | pooled | wet | 707 | 0.799 | 15056.726 | 30800.658 | 0.054 |
| 12 | ridge_history | pooled | dry | 1453 | 0.923 | 15056.726 | 18908.473 | 0.017 |
| 12 | ridge_history | pooled | high | 81 | 0.469 | 15056.726 | 147412.951 | 0.506 |
| 12 | hgb_flow | pooled | all | 2160 | 0.754 | 19624.043 | 32222.754 | 0.018 |
| 12 | hgb_flow | pooled | wet | 707 | 0.726 | 19624.043 | 39879.923 | 0.033 |
| 12 | hgb_flow | pooled | dry | 1453 | 0.768 | 19624.043 | 28496.933 | 0.01 |
| 12 | hgb_flow | pooled | high | 81 | 0.531 | 19624.043 | 100564.356 | 0.432 |
| 12 | hgb_history | pooled | all | 2160 | 0.498 | 14672.807 | 49142.131 | 0.018 |
| 12 | hgb_history | pooled | wet | 707 | 0.355 | 14672.807 | 72810.476 | 0.031 |
| 12 | hgb_history | pooled | dry | 1453 | 0.568 | 14672.807 | 37625.6 | 0.012 |
| 12 | hgb_history | pooled | high | 81 | 0.444 | 14672.807 | 117798.46 | 0.444 |
| 12 | hgb_oracle | pooled | all | 2160 | 0.866 | 7496.674 | 12588.027 | 0.017 |
| 12 | hgb_oracle | pooled | wet | 707 | 0.733 | 7496.674 | 18813.72 | 0.021 |
| 12 | hgb_oracle | pooled | dry | 1453 | 0.93 | 7496.674 | 9558.733 | 0.014 |
| 12 | hgb_oracle | pooled | high | 81 | 0.58 | 7496.674 | 23821.162 | 0.222 |


## Primary paired block bootstrap

| horizon | comparison | block_hours | MAE_difference | CI_low | CI_high |
| --- | --- | --- | --- | --- | --- |
| 12 | hgb_history minus hgb_flow | 48 | 63.411 | -526.35 | 653.466 |
| 12 | hgb_oracle minus hgb_history | 48 | -5562.997 | -6163.542 | -4957.691 |
| 12 | hgb_history minus persistence | 48 | 3866.887 | 3021.531 | 4691.166 |
| 12 | ridge_history minus persistence | 48 | 915.124 | 428.718 | 1540.39 |


## Chronological partitions

| horizon | split | n | start | end | target_mean | wet_fraction |
| --- | --- | --- | --- | --- | --- | --- |
| 12 | train | 4398 | 2024-01-20 02:00:00 | 2024-08-08 10:00:00 | 19942.159 | 0.31 |
| 12 | calibration | 2089 | 2024-08-14 13:00:00 | 2024-11-15 16:00:00 | 13727.589 | 0.206 |
| 12 | test | 2160 | 2024-11-16 05:00:00 | 2025-02-17 11:00:00 | 16447.376 | 0.327 |
| 6 | train | 4458 | 2024-01-20 02:00:00 | 2024-08-08 16:00:00 | 9947.683 | 0.308 |
| 6 | calibration | 2119 | 2024-08-14 13:00:00 | 2024-11-15 22:00:00 | 6867.473 | 0.207 |
| 6 | test | 2178 | 2024-11-16 05:00:00 | 2025-02-17 17:00:00 | 8251.582 | 0.327 |
| 24 | train | 4278 | 2024-01-20 02:00:00 | 2024-08-07 22:00:00 | 40048.944 | 0.315 |
| 24 | calibration | 2029 | 2024-08-14 13:00:00 | 2024-11-15 04:00:00 | 27468.641 | 0.208 |
| 24 | test | 2124 | 2024-11-16 05:00:00 | 2025-02-16 23:00:00 | 32753.437 | 0.327 |