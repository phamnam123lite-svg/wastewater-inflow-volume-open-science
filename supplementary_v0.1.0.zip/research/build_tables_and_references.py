"""Generate human-readable tables and bibliography from executed outputs and verified metadata."""
from pathlib import Path
import pandas as pd,json
P=Path(__file__).resolve().parent;R=P/'results'
def md(df):
    return '| '+' | '.join(map(str,df.columns))+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in df.itertuples(index=False,name=None))
m=pd.read_csv(R/'metrics.csv');i=pd.read_csv(R/'intervals.csv');b=pd.read_csv(R/'bootstrap_comparisons.csv')
out=['# Computed tables','All flow-volume errors are in m³. These tables are generated directly from CSV outputs.']
for title,df in [('Primary 12-hour point scores',m[(m.horizon==12)&(m.group=='all')]),('12-hour pooled coverage',i[(i.horizon==12)&(i.method=='pooled')]),('Primary paired block bootstrap',b[(b.horizon==12)&(b.block_hours==48)]),('Chronological partitions',pd.read_csv(R/'splits.csv'))]:
    out.extend(['\n## '+title,md(df.round(3))])
(P/'computed_tables.md').write_text('\n\n'.join(out),encoding='utf8')
refs=json.loads((P/'sources/verified_crossref.json').read_text(encoding='utf8'))
order=['10.1029/2022WR033826','10.3390/w17223225','10.1111/ecog.02881','10.1021/acsestwater.4c01047','10.1111/wej.12945']
refs.sort(key=lambda r:order.index(r['doi']) if r['doi'] in order else 100)
lines=['# Verified reference catalogue','DOI metadata retrieved from Crossref on 2026-11-09. Full metadata and initial/retry access errors are retained in sources/. Publication-year fields follow Crossref; title/author/year verification does not imply full-text methodological review.']
bib=[]
for n,r in enumerate(refs,1):
    if 'title' not in r:continue
    authors='; '.join(' '.join([a.get('given',''),a.get('family','')]).strip() for a in r['authors'])
    year=r['published']['date-parts'][0][0];title=r['title'][0];journal=r['journal'][0]
    lines.append(f'{n}. {authors} ({year}). {title}. *{journal}*. https://doi.org/{r["doi"]}')
    ba=' and '.join(a.get('family','')+', '+a.get('given','') for a in r['authors'])
    bib.append(f'@article{{verified{n},\n  author = {{{ba}}},\n  title = {{{{{title}}}}},\n  journal = {{{journal}}},\n  year = {{{year}}},\n  doi = {{{r["doi"]}}}\n}}')
lines.extend(['\n## Additional verified primary records',
'DHI (2025). Inflow to a Waste Water Treatment Plant: observations and processed data, v1. Zenodo. https://doi.org/10.5281/zenodo.15301164. Creator and license verified from Zenodo API.',
'Bøhn, E.; Eidnes, S.; Jonassen, K. R. (2024). Machine learning in wastewater treatment: insights from modelling a pilot denitrification reactor. arXiv:2412.14030. https://arxiv.org/abs/2412.14030. Preprint; not represented as verified journal publication.',
'Xu, C.; Xie, Y. (2023). Sequential Predictive Conformal Inference for Time Series. Proceedings of the 40th International Conference on Machine Learning, PMLR 202, 38707–38727. https://proceedings.mlr.press/v202/xu23r.html. Verified from PMLR; no DOI invented.'])
bib.extend(['@misc{DHI2025, author={{DHI}}, title={Inflow to a Waste Water Treatment Plant: observations and processed data}, year={2025}, doi={10.5281/zenodo.15301164}}','@misc{Bohn2024, author={Bøhn, Eivind and Eidnes, Sølve and Jonassen, Kjell Rune}, title={Machine learning in wastewater treatment: insights from modelling a pilot denitrification reactor}, year={2024}, eprint={2412.14030}, archivePrefix={arXiv}}','@inproceedings{Xu2023, author={Xu, Chen and Xie, Yao}, title={Sequential Predictive Conformal Inference for Time Series}, year={2023}, booktitle={Proceedings of the 40th International Conference on Machine Learning}, volume={202}, pages={38707--38727}, url={https://proceedings.mlr.press/v202/xu23r.html}}'])
(P/'references.md').write_text('\n\n'.join(lines),encoding='utf8');(P/'references.bib').write_text('\n\n'.join(bib),encoding='utf8')
p=pd.read_csv(R/'predictions_12h.csv',index_col=0,parse_dates=True)
starts=p.high&(~p.high.shift(1,fill_value=False)|(p.index.to_series().diff()!=pd.Timedelta(hours=1)))
summary={'high_volume_windows':int(p.high.sum()),'high_volume_contiguous_episodes':int(starts.sum()),'test_12h_windows':len(p)}
# Compute percentages from scores, not rounded manuscript values.
z=m[(m.horizon==12)&(m.group=='all')].set_index('model')
summary['weather_gain_vs_flow_MAE_pct']=100*(1-z.loc['hgb_history','MAE_m3']/z.loc['hgb_flow','MAE_m3'])
summary['oracle_gain_vs_history_MAE_pct']=100*(1-z.loc['hgb_oracle','MAE_m3']/z.loc['hgb_history','MAE_m3'])
(R/'derived_summary.json').write_text(json.dumps(summary,indent=2))
print('Tables, references and derived summary written.')
