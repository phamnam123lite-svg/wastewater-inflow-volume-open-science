# Kết quả tính toán và đánh giá khả năng phát triển bài báo

## Kết luận chính

Nghiên cứu đã được chạy thật trên dữ liệu DHI, với 7 cấu hình dự báo/baseline ở ba horizon. Kết quả hỗ trợ một bài **đánh giá giới hạn và độ tin cậy**, chưa hỗ trợ tuyên bố có công cụ tối ưu vận hành vượt trội. Mô hình dùng lịch sử khí tượng không cải thiện MAE so với mô hình chỉ dùng lịch sử flow/calendar; cả hai thua baseline đơn giản ở test cuối. Đối chứng biết mưa tương lai cải thiện mạnh ở 12 giờ, nhưng không phải mô hình triển khai thực tế.

## Dữ liệu và phép chia

Primary h=12: 4.398 training, 2.089 calibration, 2.160 test windows; tổng 8.647. Test từ 16/11/2024 05:00 đến 17/02/2025 11:00 UTC. Đó là các forecast windows chồng lấn, không phải 2.160 quan sát độc lập. Mean target training/calibration/test lần lượt 19.942/13.728/16.447 m³. Ngưỡng high volume lấy từ training: 32.304,98 m³; test có 81 cửa sổ high thuộc **5 đoạn high liên tiếp**, không phải 81 storm events độc lập. Wet state có 707 cửa sổ, xác định bằng mưa sáu giờ trước.

## Kết quả 12 giờ

| Mô hình | MAE (m³) | RMSE (m³) | R² | Vai trò |
|---|---:|---:|---:|---|
| Persistence | 3.740,22 | 6.185,43 | 0,219 | Baseline |
| Mean24 | **3.406,61** | 6.128,24 | 0,233 | MAE thấp nhất trong cấu hình chỉ dùng thông tin sẵn có |
| Seasonal24 | 4.056,77 | 7.787,93 | −0,239 | Baseline |
| Ridge + history | 4.655,34 | 5.743,78 | 0,326 | RMSE tốt hơn baseline, MAE kém hơn |
| HGB flow/calendar | 7.543,69 | 8.452,50 | −0,459 | Đối chứng không khí tượng |
| HGB + history | 7.607,10 | 8.633,01 | −0,522 | Mô hình historical chính |
| HGB + perfect future rain | 2.044,11 | 2.756,37 | 0,845 | **Oracle chẩn đoán, không triển khai được** |

Các thuật toán và siêu tham số được chọn theo CV trong training, không chọn lại theo test. Từ đây không suy ra HGB luôn kém hơn ridge hoặc baseline tại các nhà máy khác.

## Kiểm tra giả thuyết và bất định

- **H1 không được hỗ trợ**: MAE(history) − MAE(flow) = +63,41 m³; CI percentile bootstrap khối tối đa 48 giờ khoảng [−526,35; +653,47] m³. Không có bằng chứng ổn định rằng thêm lịch sử khí tượng cải thiện MAE trên holdout này.
- **H2 được hỗ trợ trong đối chứng chẩn đoán**: MAE(oracle) − MAE(history) = −5.563,00 m³, CI khoảng [−6.163,54; −4.957,69] m³; giảm khoảng 73,1%. Đây là so sánh hai pipeline được tuning riêng, không phải causal value của rain hay upper bound toán học.
- **H3 được quan sát ở mức mô tả**: pooled interval danh nghĩa 90% của mean24 có coverage toàn tập 87,5%, nhưng high-volume chỉ 23,5%. Với HGB history, lần lượt 49,8% và 44,4%. Không dùng kiểm định nhị thức độc lập cho những cửa sổ chồng lấn.

Thay block tối đa thành 24/168 giờ không đảo chiều kết luận H1/H2; CI rộng hơn khi giữ phụ thuộc dài hơn. Chỉ có một mùa test nên bootstrap không phản ánh mọi bất định qua mùa/địa điểm. Nhóm high được xác định bằng outcome để chẩn đoán lỗi; không phải một nhãn biết trước tại thời điểm dự báo.

Wet/dry calibration tăng coverage wet của mean24 từ 79,3% lên 92,9%, nhưng coverage dry giảm từ 91,5% xuống 85,8%; coverage high vẫn chỉ 34,6%. Với oracle, coverage toàn tập tăng từ 86,6% lên 90,0%, high chỉ 66,7%. Vì vậy độ phủ trung bình gần nominal không đủ để xác nhận an toàn ở các tình huống quan trọng.

Horizon sensitivity: ở 6 giờ, persistence MAE 1.567,68 m³ và oracle 937,85 m³; ở 24 giờ, mean24 6.588,94 m³ và oracle 6.617,34 m³. Lợi thế của oracle không đồng nghĩa luôn thắng mọi baseline ở mọi horizon. Không so trực tiếp trị tuyệt đối MAE giữa horizon vì tổng thể tích và tập cửa sổ thay đổi.

## Ý nghĩa kỹ thuật và chẩn đoán

HGB history có bias dương 6.811 m³ toàn tập; mean24 chỉ khoảng 230 m³. Tuy vậy, mean24 underpredict trung bình 13.924 m³ trên high subset, và 54,3% high windows vượt upper bound pooled. Đó là lỗi dự báo thể tích, **không phải dung tích bể còn thiếu được đo hoặc overflow thực**. Muốn chuyển sang storage cần inflow trajectory, trạng thái bể, capacity và dòng ra.

Residual HGB history autocorrelation ở lag 1 giờ là 0,890; lag 24 giờ là 0,153. Tương quan Spearman giữa |residual| và predicted volume khoảng 0,481. Vì vậy i.i.d. uncertainty và constant-error assumptions không phù hợp để được chấp nhận mặc định. Group-shift sensitivity cho thấy flow history quan trọng nhất trong cấu hình đã fit, nhưng tương quan giữa predictors và dịch chuyển mùa ngăn diễn giải nhân quả. Chưa chứng minh nguyên nhân duy nhất của lỗi HGB là seasonal shift; đó là giả thuyết cần nhiều năm dữ liệu để kiểm tra.

## Khả năng công bố

**Chưa khuyến nghị nộp ngay vào Q1/Q2.** Đã có dữ liệu kiểm chứng, code, benchmark và negative finding hữu ích. Điểm yếu còn lớn: một plant, chỉ 5 đoạn high trong test, không có weather forecast thực, chưa có replication độc lập, không có validation điều khiển hoặc treatment performance. Tính mới mang tính audit ứng dụng hẹp; mô hình và ý tưởng probabilistic prediction đều đã có. Không có phép đánh giá độc lập của chuyên gia/peer review.

Ưu tiên bổ sung: (1) replay forecast có issue time và latency; (2) tối thiểu một WWTP khác, nhiều mùa/năm; (3) rolling/recalibrated baselines và uncertainty methods cho chuỗi thời gian; (4) sensor fault log và missing-not-at-random sensitivity; (5) treatment/hydraulic capacity, tank levels, effluent và energy để nối forecast với kết quả vận hành; (6) rà soát citation-forward/backward và full texts gần nhất trước khi xác lập đóng góp.

## Tạp chí mục tiêu và phân hạng

Đã kiểm tra nguồn công khai ngày 09/11/2026. Phân hạng phụ thuộc **cơ sở dữ liệu, năm và ngành**; không đồng nhất SJR, CiteScore và JCR. Trang IWA chính thức cập nhật 17/07/2026 xác nhận metrics nhưng không hiển thị quartile. Không xác nhận được quartile hiện hành từ trang SCImago/JCR chính thức trong phiên này; các tín hiệu Q bên dưới từ nguồn tổng hợp chỉ để sàng lọc, cần kiểm tra lại qua cơ sở dữ liệu chính thức trước quyết định nộp.

| Tạp chí | Phù hợp | Bằng chứng hiện hành và tình trạng Q | Điều kiện trước khi nhắm tới |
|---|---|---|---|
| Journal of Hydroinformatics | Phù hợp nhất cho validation/uncertainty trong forecast thủy lực | IWA: IF 2,9; SJR 0,605. Nguồn tổng hợp báo SJR 2025 Q2, chưa xác nhận Q chính thức | Thêm benchmark robust và kiểm định đa mùa/plant |
| Water Science & Technology | Phù hợp nếu gắn rõ ứng dụng vận hành WWTP | IWA: IF 2,8; SJR 0,664. Nguồn tổng hợp báo SJR 2025 Q2; JCR thay đổi theo category, chưa xác nhận | Thêm treatment/capacity implications thực nghiệm |
| Environmental Modelling & Software | Phù hợp nếu nâng thành framework/software có tính tổng quát | Nguồn tổng hợp báo SJR 2025 Q1; trang scope ScienceDirect bị 403 trong phiên; chưa xác nhận Q chính thức | Một single-plant audit hiện tại chưa đủ mạnh; cần generalization và methodological advance |

Nguồn: [IWA journal metrics](https://iwaponline.com/pages/metrics), [Journal of Hydroinformatics chính thức](https://iwaponline.com/jh), [SJR Q2 được nguồn tổng hợp báo cho JH](https://researchcloud.net/journal/1464-7141), [WST screening record](https://scienceaijournal.com/journals/water-science-and-technology-0273-1223), [EMS screening record](https://journalindexes.com/environmental-modelling-and-software-13648152/). Không dùng các metrics này như bảo đảm chất lượng hoặc xác suất nhận bài.

## Kiểm tra chất lượng sản phẩm

Đã đối chiếu checksum dữ liệu, tính lại target sums và metrics từ predictions, xác minh chronology và kiểm tra perturbation tương lai không đổi historical features. Trong QA phát hiện vấn đề đơn vị timestamp của pandas 3 ở bootstrap, đã sửa bằng chuẩn hóa nanosecond, tính lại CI và chạy lại toàn pipeline; báo cáo chỉ dùng kết quả đã sửa. Không thay đổi mô hình dựa trên kết quả test. Các file `verification.json` và `bootstrap_run_audit.json` ghi kiểm tra. Hình đã được xem trực quan; PNG/SVG/PDF đều được xuất.
