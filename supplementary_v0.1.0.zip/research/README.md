# Wastewater inflow-volume research package

Research executed on 2026-11-09. This is an exploratory, reproducible secondary analysis, not a submission-ready claim of novelty or operational validation.

## Read first

- `01_review_and_selection_vi.md`: ten candidate topics, source limitations, suitability and overlap matrices.
- `02_research_proposal_vi.md`: research questions, hypotheses, engineering interpretation and validation design.
- `PROTOCOL.md`: protocol saved before fitting.
- `03_results_and_publication_vi.md`: computed findings and publication assessment.
- `04_manuscript_en.md`: full English IMRaD research draft.
- `references.md`, `references.bib`: verified bibliography.
- `results/`: machine-readable outputs, predictions, audit, environment and hashes.
- `figures/`: publication-oriented PNG (300 dpi), SVG and PDF figures.

## Reproduce

Python 3.11 was used. Exact installed versions are in `requirements.txt` and `results/environment.json`.

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python download_data.py
.venv\Scripts\python run_analysis.py
.venv\Scripts\python verify_results.py
```

The data already included in this package allow offline execution of `run_analysis.py`. The download step needs network access and verifies archive MD5. Metadata searches are independently reproducible with `python search_and_verify.py`, but search results and rate limits may change. Model fitting and bootstrap may take several minutes. Fixed random seed: 20261109. The bootstrap is computationally intensive and uses approximate contiguous moving blocks that shorten at data gaps.

Generated reports summarize this completed run. If modifying the protocol or rerunning with different data/versions, regenerate or revise the reports; the Markdown manuscripts are not automatically synchronized to modified computations.

## Data and use conditions

Data creator: DHI; meteorological data provider: Danish Meteorological Institute. Source: [Zenodo v1](https://doi.org/10.5281/zenodo.15301164). License recorded in Zenodo metadata: [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Original archives are unchanged. Derived cleaned data and forecasts are explicitly identified as transformations. Attribution and noncommercial conditions remain applicable. GitHub README wording is inconsistent; no commercial-reuse permission is inferred.

The package's newly written analysis scripts may be reused under MIT terms in `LICENSE_CODE.txt`; this does not relicense data or third-party source material. Original DHI notebooks in `sources/` are preserved for provenance only and retain their original rights. They are not executed by our analysis.

The article has no assigned human authors, affiliations, funding declarations or conflict-of-interest declarations. These must be supplied and verified by the research team. No manuscript, dataset or code has been publicly uploaded, submitted to a journal, or posted as a GitHub Gist.
