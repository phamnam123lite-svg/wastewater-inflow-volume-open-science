# Verified reference catalogue

DOI metadata retrieved from Crossref on 2026-11-09. Full metadata and initial/retry access errors are retained in sources/. Publication-year fields follow Crossref; title/author/year verification does not imply full-text methodological review.

1. Björn Sonnenschein; Florian Ziel (2023). Probabilistic Intraday Wastewater Treatment Plant Inflow Forecast Utilizing Rain Forecast Data and Sewer Network Sensor Data. *Water Resources Research*. https://doi.org/10.1029/2022WR033826

2. Alejandro González Barberá; Sergio Iserte; Maribel Castillo; Jaume Luis-Gómez; Raúl Martínez-Cuenca; Guillem Monrós-Andreu; Sergio Chiva (2025). Machine Learning-Based Forecasting of Wastewater Inflow During Rain Events at a Spanish Mediterranean Coastal WWTPs. *Water*. https://doi.org/10.3390/w17223225

3. David R. Roberts; Volker Bahn; Simone Ciuti; Mark S. Boyce; Jane Elith; Gurutzeta Guillera‐Arroita; Severin Hauenstein; José J. Lahoz‐Monfort; Boris Schröder; Wilfried Thuiller; David I. Warton; Brendan A. Wintle; Florian Hartig; Carsten F. Dormann (2017). Cross‐validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure. *Ecography*. https://doi.org/10.1111/ecog.02881

4. Wenqi Yang; Haiyan Li (2025). Machine Learning in Wastewater Treatment: A Comprehensive Bibliometric Review. *ACS ES&amp;T Water*. https://doi.org/10.1021/acsestwater.4c01047

5. Taher Abunama; Antoine Dellieu; Stéphane Nonet (2024). Advancements in machine learning modelling for energy and emissions optimization in wastewater treatment plants: A systematic review. *Water and Environment Journal*. https://doi.org/10.1111/wej.12945

6. Zeeshan Haider Jaffari; Heewon Jeong; Jaegwan Shin; Jinwoo Kwak; Changgil Son; Yong-Gu Lee; Sangwon Kim; Kangmin Chon; Kyung Hwa Cho (2023). Machine-learning-based prediction and optimization of emerging contaminants' adsorption capacity on biochar materials. *Chemical Engineering Journal*. https://doi.org/10.1016/j.cej.2023.143073

7. Alberto Zoccali; Beatrice Cantoni; Arianna Azzellino; Francesca Malpei (2025). Removal of microplastics in wastewater treatment plants: insights from a literature meta-analysis. *Journal of Environmental Chemical Engineering*. https://doi.org/10.1016/j.jece.2025.116812

8. Elinor S. Austin; Dana M. Austin; Linda Y. Tseng; Lin Liu; Zeth Kleinmeyer; Danielle Drake; Diego Rosso; Yian Sun (2025). Meta-analysis on microplastics monitoring in global water resource recovery facilities: An emphasis on overlooked factors. *Environmental Pollution*. https://doi.org/10.1016/j.envpol.2025.127220

9. Stefano Cairone; Shadi W. Hasan; Kwang-Ho Choo; Chi-Wang Li; Tiziano Zarra; Vincenzo Belgiorno; Vincenzo Naddeo (2024). Integrating artificial intelligence modeling and membrane technologies for advanced wastewater treatment: Research progress and future perspectives. *Science of The Total Environment*. https://doi.org/10.1016/j.scitotenv.2024.173999

10. Byron Oviedo-Bayas (2026). Machine learning-based classification of operating regimes in an urban wastewater treatment plant: a benchmark on reconstructed reference labels. *Frontiers in Environmental Science*. https://doi.org/10.3389/fenvs.2026.1941653

11. Caihong Liu; Chi Xiong; Hai Liang; Kun Yang; Andreia F. Faria; Liu Yang; Amauri J. Paula; Hongtao Li; Dan Song; Qiang He; Jun Ma (2026). Membrane-based advanced oxidation processes for water and wastewater treatment: Advances, trade-offs, and challenges. *Chemical Engineering Journal*. https://doi.org/10.1016/j.cej.2026.178098

12. Reyhan Ata (2025). Integration of artificial intelligence in advanced oxidation processes for sustainable wastewater treatment: A bibliometric and scientometric analysis (2014–2025). *Desalination and Water Treatment*. https://doi.org/10.1016/j.dwt.2025.101338

13. Wen-Long Xu; Ya-Jun Wang; Yi-Tong Wang; Jun-Guo Li; Ya-Nan Zeng; Hua-Wei Guo; Huan Liu; Kai-Li Dong; Liang-Yi Zhang (2024). Application and innovation of artificial intelligence models in wastewater treatment. *Journal of Contaminant Hydrology*. https://doi.org/10.1016/j.jconhyd.2024.104426

14. Tian Shen; Haoyi Peng; Xingzhong Yuan; Yunshan Liang; Shengqiang Liu; Zhibin Wu; Lijian Leng; Pufeng Qin (2024). Feature engineering for improved machine-learning-aided studying heavy metal adsorption on biochar. *Journal of Hazardous Materials*. https://doi.org/10.1016/j.jhazmat.2024.133442

15. Sara Iftikhar; Rehan Ishtiaq; Nallain Zahra; Fazila Ruba; Sze-Mun Lam; Ather Abbas; Zeeshan Haider Jaffari (2025). Probabilistic prediction of phosphate ion adsorption onto biochar materials using a large dataset and online deployment. *Chemosphere*. https://doi.org/10.1016/j.chemosphere.2024.144031

16. Sirajum Monira; Linhua Fan; Will McCance; Rajeev Roychand; Muhammed Ali Bhuiyan; Kalpit Shah; Michael Thomas; Biplob Kumar Pramanik (2025). Seasonal variation and removal efficiency of microplastics in wastewater treatment: a year-long study across three municipal water reclamation plants. *Environmental Science: Water Research &amp; Technology*. https://doi.org/10.1039/D4EW00924J

17. Abdullah A. Alsumaiei (2026). Regularized and explainable machine learning framework for anthropogenic–climate coupled prediction of wastewater influent in hyper-arid urban utilities. *Water Science &amp; Technology*. https://doi.org/10.2166/wst.2026.205


## Additional verified primary records

DHI (2025). Inflow to a Waste Water Treatment Plant: observations and processed data, v1. Zenodo. https://doi.org/10.5281/zenodo.15301164. Creator and license verified from Zenodo API.

Bøhn, E.; Eidnes, S.; Jonassen, K. R. (2024). Machine learning in wastewater treatment: insights from modelling a pilot denitrification reactor. arXiv:2412.14030. https://arxiv.org/abs/2412.14030. Preprint; not represented as verified journal publication.

Xu, C.; Xie, Y. (2023). Sequential Predictive Conformal Inference for Time Series. Proceedings of the 40th International Conference on Machine Learning, PMLR 202, 38707–38727. https://proceedings.mlr.press/v202/xu23r.html. Verified from PMLR; no DOI invented.